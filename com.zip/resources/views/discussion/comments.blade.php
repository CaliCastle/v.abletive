@foreach($comments as $comment)
    @include('discussion.comment-list')
@endforeach