<section class="level-up">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="callout col-lg-4 col-lg-offset-8">
                <h3>{{ trans('app/site.level-up.heading') }}</h3>
                <p>{{ trans('app/site.level-up.paragraph') }}</p>
                <p>{{ trans('app/site.level-up.paragraph-2') }}</p>
            </div>
        </div>
    </div>
</section>