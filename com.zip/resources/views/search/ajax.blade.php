@include('search.series-results')

@include('search.lessons-results')

@include('search.users-results')

@include('search.tags-results')