<?php

return [
    "live" => "Ableton Live",
    "launchpad" => "Launchpad",
    "produce" => "Music Production",
    "dj" => "DJ",
    "controller" => "Controllerism",
    "skill" => "Skill"
];