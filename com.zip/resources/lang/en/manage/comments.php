<?php

return [
    "title" => "Manage Comments",
    "user" => "User",
    "video" => "Lesson",
    "message" => "Message"
];