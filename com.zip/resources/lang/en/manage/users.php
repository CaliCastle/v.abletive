<?php

return [
    "title" => "Manage Users",
    "name" => "Nickname",
    "email" => "Email",
    "role" => "Role",
    "promote" => "Promote",
    "unpromote" => "Unpromote",
    "promote-title" => "Are You Sure?",
    "promote-success" => "Succeeded!"
];