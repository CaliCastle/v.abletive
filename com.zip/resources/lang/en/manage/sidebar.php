<?php

return [
    "index" => "Dashboard",
    "series" => "Series",
    "lessons" => "Lessons",
    "users" => "Users",
    "comments" => "Comments",
    "skills" => "Skills"
];