<?php

return [
    "title" => "Manage Skills",
    "edit_title" => "Edit Skill",
    'name' => "Name",
    "series" => "Series Count",
    "edit" => "Edit",
    "update" => "Update",
    "thumbnail" => "Thumbnail URL",
    "description" => "Description"
];