<?php

return [
    "beginner" => "Beginner",
    "starting" => "Noob",
    "intermediate" => "Intermediate",
    "skilled" => "Sophisticated",
    "maestro" => "Maestro"
];