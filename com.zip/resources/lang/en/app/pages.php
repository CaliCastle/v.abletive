<?php

return [
    "index" => "Painless Learning",
    "login" => "Sign In",
    "register" => "Sign Up a New Account",
];