<?php

return [
    "logout" => [
        "heading" => "Are you sure?",
        "message" => "If you logout, you might not be able to visit certain pages",
        "confirm" => "Log me out!"
    ],
    "cancel" => "Cancel",
];