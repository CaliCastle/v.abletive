<?php

return [
    "title" => "Tags",
    "subtitle" => "Pick the ones you're interested in",
    "detail_title" => "Lessons Containing Tag {:name}",
    "detail_subtitle" => ":count Related Lessons",
];