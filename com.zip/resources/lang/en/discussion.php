<?php

return [
    "placeholder" => "Say what you wanna say, nobody's judging. Discussion makes improvement...",
    "login-message" => "Please <a href=\"javascript:;\" id=\"login-btn\">Sign In</a> first to join the discussion",
    "submit" => "Submit",
    "hots" => "Hot Discussions",
    "insert" => "Insert the current timeline",
    "timecode" => "Play video at this timeline",
    "like" => "Like this",
    "reply" => "Reply to this",
    "comment" => "Comment",
    "tutor" => "TUTOR",
    "manager" => "MANAGER",
    "cancel" => "Cancel Reply",
    "insert_image" => "Upload Images",
    "load_more" => "Load More Comments",
    "validation" => "Drag to move the cubes and match CALI"
];