<?php

return [
    "account" => "Account",
    "notification" => "Notification",
    "subscription" => "Subscription",
    "level" => "Level / Experience"
];