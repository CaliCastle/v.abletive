<?php

return [
    "title" => "Subscription Information",
    "other" => "To renew/become subscription, visit <a href=\":link\" target=\"_blank\">This Page</a>"
];