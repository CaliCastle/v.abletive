<?php

return [
    "title" => "Different Levels",
    "your-xp" => "Current XP: :xp",
    "level-name" => "Level Name",
    "level-xp" => "XP Needed"
];