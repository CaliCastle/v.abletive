<?php

return [
    "index" => "仪表盘",
    "series" => "课程系列",
    "lessons" => "课程视频",
    "users" => "用户",
    "comments" => "评论",
    "skills" => "技能"
];