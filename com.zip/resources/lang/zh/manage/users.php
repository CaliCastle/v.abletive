<?php

return [
    "title" => "用户管理",
    "name" => "昵称",
    "email" => "Email",
    "role" => "权限",
    "promote" => "提升讲师",
    "unpromote" => "取消讲师",
    "promote-title" => "确定此操作吗?",
    "promote-success" => "已成功"
];