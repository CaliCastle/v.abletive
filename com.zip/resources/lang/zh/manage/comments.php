<?php

return [
    "title" => "评论管理",
    "user" => "用户",
    "video" => "课程",
    "message" => "内容"
];