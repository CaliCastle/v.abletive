<?php

return [
    "title" => "管理技能",
    "edit_title" => "编辑技能",
    'name' => "名称",
    "series" => "课程总数",
    "edit" => "编辑",
    "update" => "更新",
    "thumbnail" => "图片地址",
    "description" => "介绍"
];