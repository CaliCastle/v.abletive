<?php

return [
    "placeholder" => "说你想说的, 无论对与错. 只有讨论才能进步...",
    "login-message" => "请先<a href=\"javascript:;\" id=\"login-btn\">登录</a>才能加入讨论",
    "submit" => "提交评论",
    "hots" => "热门讨论",
    "insert" => "插入当前视频时间",
    "timecode" => "从此播放视频",
    "like" => "点赞",
    "reply" => "回复",
    "comment" => "评论",
    "tutor" => "讲师",
    "manager" => "管理君",
    "cancel" => "取消回复",
    "insert_image" => "添加图片",
    "load_more" => "加载更多评论",
    "validation" => "评论验证:拖动方块组成CALI"
];