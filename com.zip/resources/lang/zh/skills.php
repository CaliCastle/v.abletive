<?php

return [
    "live" => "Ableton Live",
    "launchpad" => "Launchpad",
    "produce" => "音乐制作",
    "dj" => "DJ",
    "controller" => "控制器",
    "skill" => "技能"
];