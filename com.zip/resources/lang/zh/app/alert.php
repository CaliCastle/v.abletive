<?php

return [
    "logout" => [
        "heading" => "确定要注销吗?",
        "message" => "如果确定, 注销后有些页面将无法访问",
        "confirm" => "注销吧!"
    ],
    "cancel" => "取消",
];