<?php

return [
    "beginner" => "登门拜访",
    "starting" => "初入师门",
    "intermediate" => "渐入佳境",
    "skilled" => "炉火纯青",
    "maestro" => "青出于蓝"
];