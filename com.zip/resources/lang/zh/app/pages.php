<?php

return [
    "index" => "技能学习",
    "login" => "登录",
    "register" => "注册新账号",

];