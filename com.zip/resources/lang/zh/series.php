<?php

return [
    "lessons" => "节课",
    "minutes" => "分钟",
    "complete" => "已学习 <span class='percent'>:percent</span>",
    "xp" => "经验",
    "series-lessons" => "系列课程",
    "callout" => "慢慢来, 你就能掌握",
    "watch-later" => "晚点再看",
    "new" => "全新",
    "development" => "该系列还未完结. 常回来看看是否有更新.",
    "favorite" => "添加最爱",
    "notify" => "更新时通知",
    "title" => "系列课程",
    "subtitle" => "一系列课程可以让你一步步地学习所需的知识"
];