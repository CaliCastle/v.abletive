<?php

return [
    "title" => "会员信息",
    "other" => "充值会员请前往 <a href=\":link\" target=\"_blank\">社区网站</a>"
];