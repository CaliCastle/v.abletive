<?php

return [
    "account" => "帐号设置",
    "notification" => "通知设置",
    "subscription" => "会员",
    "level" => "等级"
];