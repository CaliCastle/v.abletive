<?php

return [
    "title" => "经验/等级详情",
    "your-xp" => "目前经验: :xp",
    "level-name" => "等级名称",
    "level-xp" => "所需经验"
];