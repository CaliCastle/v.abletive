<?php

return [
    "title" => "更新帐号设置",
    "slug" => "个人主页链接后缀",
    "display_name" => "显示昵称",
    "description" => "自我介绍",
    "password-tip" => "注意: 在社区修改的密码将不会修改本站帐号的密码",
    "password" => "修改密码",
    "password_placeholder" => "留空则不修改",
    "confirm_password" => "再次输入以确认",
    "update" => "确认更新",
    "other" => "头像与其他信息请前往 <a href=\":link\" target=\"_blank\">社区网站</a> 修改",
    "sync-message" => "资料跟社区不同步?",
    "sync-link" => "点我更新"
];