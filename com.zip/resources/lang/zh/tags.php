<?php

return [
    "title" => "标签",
    "subtitle" => "寻找你感兴趣的内容",
    "detail_title" => "标签{:name}相关的课程",
    "detail_subtitle" => "共:count个相关课程",
];