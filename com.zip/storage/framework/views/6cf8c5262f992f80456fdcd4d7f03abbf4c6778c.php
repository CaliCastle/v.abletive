<?php $__env->startSection('title', '404'); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container animated animated-delay1 bounceIn">
            <div class="row">
                <div class="nothing-found text-center">
                    <h1><i class="fa fa-meh-o"></i> 404</h1>
                    <h1><?php echo trans('app/site.404'); ?></h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>