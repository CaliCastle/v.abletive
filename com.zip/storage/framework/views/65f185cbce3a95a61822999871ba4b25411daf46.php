<?php $__env->startSection('title', isset($keyword) ? trans('manage/lessons.search-title', ["keyword" => $keyword]) : trans('manage/lessons.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('series.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(isset($keyword) ? trans('manage/lessons.search-title', ["keyword" => $keyword]) : trans('manage/lessons.title')); ?> <a href="<?php echo e(url('publish/lessons/create')); ?>"><i class="fa fa-plus-circle"></i></a>
                        <a href="javascript:;" id="search-button"><i class="fa fa-search"></i></a></h2>
                    <div class="row">
                        <?php if(count($lessons)): ?>
                            <table class="table table-striped table-responsive">
                                <thead>
                                <tr>
                                    <td><?php echo e(trans('manage/lessons.table_header.title')); ?></td>
                                    <td><?php echo e(trans('manage/lessons.table_header.duration')); ?></td>
                                    <td><?php echo e(trans('manage/lessons.table_header.series')); ?></td>
                                    <td><?php echo e(trans('manage/lessons.table_header.tutor')); ?></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($lessons as $lesson): ?>
                                    <tr data-id="<?php echo e($lesson->id); ?>">
                                        <td><a href="<?php echo e(action('HomeController@showEditLesson', ["id" => $lesson->id])); ?>"><?php echo e(str_limit($lesson->title, 20)); ?></a></td>
                                        <td><?php echo e($lesson->duration); ?></td>
                                        <td><a href="<?php echo e($lesson->series->link()); ?>" target="_blank"><?php echo e(str_limit($lesson->series->title, 20)); ?></a></td>
                                        <td><?php echo e(str_limit($lesson->user->display_name, 10)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('lessons.lesson')])); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts.footer'); ?>
<script>
    $(function () {
        $("a#search-button").click(function () {
            swal({
                title: "<?php echo e(trans('manage/series.search_box_title')); ?>",
                text: "<?php echo e(trans('manage/series.search_box_message')); ?>:",
                type: "input",
                inputType: "search",
                showCancelButton: true,
                closeOnConfirm: true,
                cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                confirmButtonText: "<?php echo e(trans('messages.search_button')); ?>",
                animation: "slide-from-bottom",
            }, function (inputValue) {
                if (inputValue === false) return;
                if (inputValue === "") {
                    swal.showInputError("...");
                    return;
                }
                window.location.href = "<?php echo e(url('publish/lessons/search/')); ?>/" + inputValue;
            });
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>