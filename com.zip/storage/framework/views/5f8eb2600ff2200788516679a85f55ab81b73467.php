<?php $__env->startSection('scripts.footer'); ?>
<script>
    function showStatusMessage(message) {
        // create the notification
        var notification = new NotificationFx({
            message : '<span class="icon fa fa-bullhorn"></span><p class="animated animated-delay1 rubberBand">' + message + '</p>',
            layout : 'attached',
            effect : 'bouncyflip',
            type : 'notice', // notice, warning or error,
            ttl : 5000 ,
            onClose : function() {

            }
        });
        // show the notification
        notification.show();
    }

    function showGenieMessage(message) {
        // create the notification
        var notification = new NotificationFx({
            message : '<p class="animated animated-delay1 rubberBand">' + message + '</p>',
            layout : 'growl',
            effect : 'genie',
            type : 'notice', // notice, warning or error,
            ttl : 5000 ,
            onClose : function() {

            }
        });
        // show the notification
        notification.show();
    }

    function showCookieMessage(message) {
        // create the notification
        var notification = new NotificationFx({
            message : '<p class="animated animated-delay7 bounceInDown">' + message + '</p>',
            layout : 'bar',
            effect : 'exploader',
            type : 'notice', // notice, warning or error,
            ttl : 9000000 ,
            onClose : function() {

            }
        });
        // show the notification
        notification.show();
    }

    (function () {
        <?php if(isset($errors)): ?>
            <?php if($errors->first()): ?>
            showStatusMessage("<?php echo e($errors->first()); ?>")
            <?php endif; ?>
        <?php endif; ?>
        <?php if(session('status')): ?>
        showStatusMessage("<?php echo session('status'); ?>");
        <?php endif; ?>
        <?php if(session('notification')): ?>
        showGenieMessage("<?php echo session('notification'); ?>");
        <?php endif; ?>
        <?php if ( ! (request()->hasCookie('allows_cookie'))): ?>
        showCookieMessage("<?php echo trans('app/site.cookie'); ?>");

        $('a#cookie-button').on('click', function () {
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('allows_cookie')); ?>",
                data: {_token: "<?php echo e(csrf_token()); ?>"},
                dataType: 'text',
                success: function (data) {
                    if (data == "Allowed") {
                        $(".ns-bar.ns-effect-exploader").fadeOut(500);
                        showGenieMessage("<?php echo trans('app/site.allowed_cookie'); ?>");
                    }
                }
            })
        });
        <?php endif; ?>
    })();
</script>
<?php $__env->appendSection(); ?>