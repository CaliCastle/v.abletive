<?php if(count($lessons)): ?><li class="divider" data-content="<?php echo e(trans('lessons.skill_lessons')); ?>"></li><?php endif; ?>
<?php foreach($lessons as $lesson): ?>
<li class="lesson-item item">
    <a href="<?php echo e($lesson->link()); ?>">
        <h3><?php echo e($lesson->title); ?></h3>
        <p><?php echo $lesson->description; ?></p>
    </a>
</li>
<?php endforeach; ?>