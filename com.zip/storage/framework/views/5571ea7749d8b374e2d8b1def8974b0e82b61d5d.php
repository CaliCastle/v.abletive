<?php $__env->startSection('title', 'Setting'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <nav class="main-nav">
                <ul>
                    <li class="active">
                        <a href="">Account</a>
                        <i class="fa fa-chevron-right"></i>
                    </li>
                    <li>
                        <a href="">Account</a>
                        <i class="fa fa-chevron-right"></i>
                    </li>
                </ul>
            </nav>
            <div class="box-right">
                <div class="content">
                    <h2 class="heading">Update Your Account</h2>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>