<form action="<?php echo e($url); ?>" method="POST" class="setting-form">
    <?php echo csrf_field(); ?>

    <div class="form-group<?php echo e($errors->has('title') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/lessons.create.title')); ?>:</label>
        <input type="text" class="form-control" name="title" value="<?php echo e(old('title') ? old('title') : $lesson->title); ?>">
        <?php if($errors->has('title')): ?>
            <strong class="has-error"><?php echo e($errors->first('title')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('source') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/lessons.create.source')); ?>:</label>
        <input type="text" class="form-control" name="source" value="<?php echo e(old('source') ? old('source') : $lesson->source); ?>">
        <?php if($errors->has('source')): ?>
            <strong class="has-error"><?php echo e($errors->first('source')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('duration') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/lessons.create.duration')); ?>:</label>
        <input type="text" class="form-control" name="duration" value="<?php echo e(old('duration') ? old('duration') : $lesson->duration); ?>">
        <?php if($errors->has('duration')): ?>
            <strong class="has-error"><?php echo e($errors->first('duration')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('experience') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/lessons.create.experience')); ?>:</label>
        <select class="form-control" name="experience" id="xp-select">
            <?php for($i = 100; $i <= 1000; $i+=100): ?>
                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
        <?php if($errors->has('experience')): ?>
            <strong class="has-error"><?php echo e($errors->first('experience')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('description') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/lessons.create.description')); ?>:</label>
        <textarea name="description" class="form-control"><?php echo old('description') ? old('description') : $lesson->description; ?></textarea>
        <?php if($errors->has('description')): ?>
            <strong class="has-error"><?php echo e($errors->first('description')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label><?php echo e(trans('manage/lessons.create.tags')); ?>:</label>
        <select class="form-control" name="tags[]" id="tag-select" multiple>
            <?php foreach($lesson->tags as $tag): ?>
                <option value="<?php echo e($tag->name); ?>" selected><?php echo e($tag->name); ?></option>
            <?php endforeach; ?>
            <?php foreach(\App\Tag::newest()->take(15)->get() as $tag): ?>
                <?php if ( ! (array_has($lesson->tags->lists('name', 'name')->toArray(), $tag->name))): ?>
                <option value="<?php echo e($tag->name); ?>"><?php echo e($tag->name); ?></option>
                <?php endif; ?>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label><?php echo e(trans('manage/lessons.table_header.series')); ?>:</label>
        <select class="form-control" name="series_id" id="series-select">
            <?php foreach(\App\Series::latest()->get() as $series): ?>
                <option value="<?php echo e($series->id); ?>"<?php echo e($lesson->series_id == $series->id ? " selected" : ""); ?>><?php echo e($series->title); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <div class="checkbox">
            <input type="checkbox" name="need_subscription"<?php echo e($lesson->needSubscription() ? " checked" : ""); ?>><?php echo e(trans('manage/lessons.need_subscription')); ?>

        </div>
    </div>
    <div class="form-group">
        <input class="btn btn-block btn-primary" type="submit" value="<?php echo e($button_text); ?>">
    </div>
    <?php if($type == "edit" && auth()->user()->isManager()): ?>
    <div class="form-group">
        <a class="btn btn-block btn-danger" href="javascript:;" id="delete-btn"><?php echo e(trans('manage/series.delete_button')); ?></a>
    </div>
    <?php endif; ?>
</form>