<?php $__env->startSection('title', isset($keyword) ? trans('manage/series.search-title', ["keyword" => $keyword]) : trans('manage/series.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(isset($keyword) ? trans('manage/series.search-title', ["keyword" => $keyword]) : trans('manage/series.title')); ?> <a href="<?php echo e(url('manage/series/create')); ?>"><i class="fa fa-plus-circle"></i></a>
                        <a href="javascript:;" id="search-button"><i class="fa fa-search"></i></a></h2>
                    <div class="row">
                        <?php if(count($series)): ?>
                            <table class="table table-striped table-responsive">
                                <thead>
                                <tr>
                                    <td><?php echo e(trans('manage/series.table_header.title')); ?></td>
                                    <td><?php echo e(trans('manage/series.table_header.lessons')); ?></td>
                                    <td><?php echo e(trans('manage/series.table_header.completed')); ?></td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($series as $s): ?>
                                    <tr data-id="<?php echo e($s->id); ?>">
                                        <td><a class="title" href="<?php echo e($s->link()); ?>" target="_blank"><?php echo e(str_limit($s->title, 35)); ?></a></td>
                                        <td><?php echo e($s->lessons->count()); ?></td>
                                        <td><span><?php echo $s->completed ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'; ?></span></td>
                                        <td><a class="btn btn-primary" href="<?php echo e(action('ManageController@showEditSeries', ["id" => $s->id])); ?>"><?php echo e(trans('manage/series.edit_button')); ?></a> <a class="btn btn-danger" id="delete-btn" href="javascript:;"><?php echo e(trans('manage/series.delete_button')); ?></a></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <div class="row text-center">
                                <p>
                                    <?php echo $series->links(); ?>

                                </p>
                            </div>
                        <?php else: ?>
                            <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('series.series-lessons')])); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script>
    $(function () {
        $("a#search-button").click(function () {
            swal({
                title: "<?php echo e(trans('manage/series.search_box_title')); ?>",
                text: "<?php echo e(trans('manage/series.search_box_message')); ?>:",
                type: "input",
                inputType: "search",
                showCancelButton: true,
                closeOnConfirm: true,
                cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                confirmButtonText: "<?php echo e(trans('messages.search_button')); ?>",
                animation: "slide-from-bottom",
            }, function (inputValue) {
                if (inputValue === false) return;
                if (inputValue === "") {
                    swal.showInputError("...");
                    return;
                }
                window.location.href = "<?php echo e(url('manage/series/search/')); ?>/" + inputValue;
            });
        });

        function deleteDidClick($id) {
            swal({
                title: "<?php echo e(trans('messages.are_you_sure_delete')); ?>",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                confirmButtonText: "<?php echo e(trans('messages.delete_button')); ?>",
                showLoaderOnConfirm: true,
                closeOnConfirm: false
            }, function () {
                $.ajax({
                    url: "<?php echo e(url('manage/series')); ?>/" + $id,
                    type: "DELETE",
                    data: {_token: "<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success: function (data) {
                        swal({title:data.message, type:data.status,timer: 1000,showConfirmButton: false});
                        var selector = 'tr[data-id="' + $id + '"]';
                        $(selector).fadeOut(1000,function() {$(this).remove()});
                    }
                });
            });
        }

        $('a#delete-btn').each(function () {
            $(this).click(function () {
                deleteDidClick($($(this).parents('tr')[0]).attr('data-id'));
            });
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>