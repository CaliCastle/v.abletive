<?php $__env->startSection('title', trans('profile.laters_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="timeline">
            <div class="row">
                <h2 class="big-heading">
                    <span class="subtitle"><?php echo e(trans('profile.laters_subtitle')); ?></span>
                    <span><?php echo e(trans('profile.laters_title')); ?></span>
                </h2>
            </div>
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1">
                    <?php echo $__env->make('series.partials.lesson-special-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script>
    $(function () {
        var $_token = "<?php echo e(csrf_token()); ?>";
        // Lesson watch later
        $('a#watch-later-btn-icon').each(function () {
            var el = $(this);
            $(this).click(function () {
                $id = $($(this).parents('li')[0]).attr('video-id');
                $.ajax({
                    url: "<?php echo e(url('lessons/watch_later')); ?>/" + $id,
                    type: "POST",
                    data: {_token: $_token},
                    dataType: "json",
                    success: function (data) {
                        el.toggleClass('active');
                        swal({title: data.message, type: "success", timer: 1500, showConfirmButton: false});
                    }
                });
            });
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>