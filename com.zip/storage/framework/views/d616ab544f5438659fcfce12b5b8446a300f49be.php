<?php if(count($users)): ?><li class="divider" data-content="<?php echo e(trans('auth.user')); ?>"></li><?php endif; ?>
<?php foreach($users as $user): ?>
<li class="user-item item">
    <a href="<?php echo e($user->profileLink()); ?>">
        <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->display_name); ?>">
        <span class="meta">
            <h3><?php echo e($user->display_name); ?></h3>
            <p><?php echo e($user->description); ?></p>
        </span>
    </a>
</li>
<?php endforeach; ?>