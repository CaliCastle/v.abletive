<section class="series-lessons">
    <h2 class="big-heading">
        <span class="subtitle"><?php echo e(trans('series.series-lessons')); ?></span>
        <span><?php echo e($series->title); ?></span>
    </h2>
    <div class="section row grid">
        <div class="col-lg-3">
            <div class="series-thumbnail animated animated-delay8 fadeInDown">
                <img src="<?php echo e($series->thumbnail); ?>" alt="<?php echo e($series->title); ?>">
            </div>
            <?php if ( ! ($series->completed)): ?>
            <div class="lesson-actions">
                <ul class="actions">
                    <li class="animated animated-delay11 fadeInRight">
                        <a href="javascript:;" class="action-button<?php echo e(auth()->check() ? auth()->user()->hasNotified($series) ? " active" : "" : ""); ?>" id="series-notify-btn"><i class="fa fa-btn fa-envelope"></i> <?php echo e(trans('series.notify')); ?></a>
                    </li>
                </ul>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-9">
            <ul class="lesson-list lesson-list--numbered animated animated-delay7 fadeIn">
                <?php foreach($series->lessons as $lesson): ?>
                    <li class="lesson-item<?php echo e(auth()->check() ? auth()->user()->hasWatched($lesson) ? " lesson--completed" : "" : ""); ?> animated fadeInUp" video-id="<?php echo e($lesson->id); ?>">
                        <span class="status"><i class="fa fa-check-circle"></i></span>
                                    <span class="title"><a href="<?php echo e($lesson->link()); ?>"><?php echo e($lesson->title); ?>

                                            <?php echo $lesson->recentlyPublished() ? '<span class="new">' . trans('series.new') . '!</span>' : ''; ?></a></span>
                        <span class="length"><?php echo e($lesson->duration); ?></span>
                        <?php if ( ! (Auth::guest())): ?>
                        <span class="watch-later"><a href="javascript:;" id="watch-later-btn-icon" title="<?php echo e(trans('series.watch-later')); ?>"><i class="fa fa-clock-o"></i></a></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <?php if ( ! ($series->completed)): ?>
            <p class="development">
                <?php echo e(trans('series.development')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
</section>