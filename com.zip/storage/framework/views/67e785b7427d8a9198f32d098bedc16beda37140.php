<?php $__env->startSection('title', trans('tags.title')); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="row text-center section">
                <h1 class="heading animated animated-delay1 fadeInUp"><?php echo e(trans('tags.title')); ?></h1>
                <h3 class="callout animated animated-delay3 fadeInUp"><?php echo e(trans('tags.subtitle')); ?></h3>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="tags section">
            <div class="row">
                <ul class="tag-list animated animated-delay5 bounceIn">
                    <?php $__empty_1 = true; foreach($tags as $tag): $__empty_1 = false; ?>
                        <li class="tag"><a href="<?php echo e($tag->link()); ?>"><?php echo e($tag->name); ?></a></li>
                    <?php endforeach; if ($__empty_1): ?>
                        <h2 class="no-result"></h2>
                    <?php endif; ?>
                </ul>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>