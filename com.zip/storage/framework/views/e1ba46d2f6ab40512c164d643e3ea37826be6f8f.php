<?php $__env->startSection('title', trans('app/pages.index')); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <h1 class="heading animated fadeInUp"><?php echo trans('app/site.welcome.heading'); ?></h1>
                    <h3 class="callout animated animated-delay3 fadeInUp"><?php echo trans('app/site.welcome.callout'); ?></h3>
                    <h3 class="description animated animated-delay5 fadeInUp"><?php echo trans('app/site.welcome.description'); ?></h3>
                </div>
            </div>
            <div class="row">
                <div class="text-center animated animated-delay6 fadeInUp">
                    <h4 class="start"><a href="<?php echo e(url('series')); ?>" class="btn btn-primary"><?php echo trans('app/site.welcome.start'); ?></a></h4>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container">
        <div class="row">
            <div class="block-message animated animated-delay8 fadeInUp">
                <h2><?php echo e(trans('app/site.features.block-message')); ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="featured-title animated animated-delay10 fadeIn">
                <span><a href=""><?php echo e(trans('app/site.features.featured-series')); ?></a></span>
            </div>
        </div>
        <div class="row">
            <div class="series-collection">
                <?php $__empty_1 = true; foreach(\App\Series::featured() as $series): $__empty_1 = false; ?>
                    <?php echo $__env->make('series.partials.series-tiles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; if ($__empty_1): ?>
                    <h2 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('series.title')])); ?></h2>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="featured-title">
                <span><a href=""><?php echo e(trans('app/site.features.featured-skills')); ?></a></span>
            </div>
        </div>
        <div class="row">
            <div class="skills-collection">
                <?php foreach(\App\Skill::all() as $skill): ?>
                    <div class="skill">
                        <a href="<?php echo e(url('skills/' . $skill->name)); ?>">
                            <img src="<?php echo e($skill->thumbnail); ?>" alt="">
                        </a>
                        <span><?php echo e(trans('skills.' . $skill->name)); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.partials.level-up', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="testimonials">
    <div class="container">
        <div class="row">
            <div class="block-message">
                <h2><?php echo e(trans('app/site.testimonials.block-message')); ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="featured-title">
                <span><?php echo e(trans('app/site.testimonials.featured-title')); ?></span>
            </div>
        </div>
        <div class="row">
            <div class="testimonials-collection">
                <?php for($i = 1; $i <= 10; $i++): ?>
                    <div class="testimonial">
                        <?php if(trans("testimonials.{$i}.link") != "testimonials.${i}.link"): ?>
                            <a href="<?php echo e(trans("testimonials.{$i}.link")); ?>" target="_blank"><img class="avatar" src="<?php echo e(url('assets/images/testimonials') . '/' . trans("testimonials.{$i}.avatar")); ?>" alt=""></a>
                        <?php else: ?>
                            <img class="avatar" src="<?php echo e(url('assets/images/testimonials') . '/' . trans("testimonials.{$i}.avatar")); ?>" alt="">
                        <?php endif; ?>
                        <h4 class="name"><?php echo e(trans("testimonials.{$i}.name")); ?></h4>
                        <h5 class="caption"><?php echo e(trans("testimonials.{$i}.caption")); ?></h5>
                        <blockquote class="message"><?php echo e(trans("testimonials.{$i}.message")); ?></blockquote>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
        <div class="row">
            <div class="see-more">
                <span><a href="<?php echo e(url('testimonials')); ?>"><?php echo e(trans('testimonials.see-more')); ?> <i class="fa fa-btn fa-chevron-right"></i></a></span>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>