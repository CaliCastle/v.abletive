<?php $__env->startSection('title', trans('app/site.testimonials.block-message')); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="row section">
                <div class="text-center">
                    <h1 class="heading animated animated-delay1 fadeInUp"><?php echo e(trans('app/site.testimonials.block-message')); ?></h1>
                    <h3 class="callout animated animated-delay3 fadeInUp"><?php echo e(trans('app/site.testimonials.featured-title')); ?></h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="testimonials">
        <div class="container">
            <div class="section">
                <div class="row" style="margin: 50px 0">
                    <div class="testimonials-collection">
                        <?php for($i = 1; $i < count(trans('testimonials')); $i++): ?>
                            <div class="testimonial">
                                <?php if(trans("testimonials.{$i}.link") != "testimonials.${i}.link"): ?>
                                    <a href="<?php echo e(trans("testimonials.{$i}.link")); ?>" target="_blank"><img class="avatar" src="<?php echo e(url('assets/images/testimonials') . '/' . trans("testimonials.{$i}.avatar")); ?>" alt=""></a>
                                <?php else: ?>
                                    <img class="avatar" src="<?php echo e(url('assets/images/testimonials') . '/' . trans("testimonials.{$i}.avatar")); ?>" alt="">
                                <?php endif; ?>
                                <h4 class="name"><?php echo e(trans("testimonials.{$i}.name")); ?></h4>
                                <h5 class="caption"><?php echo e(trans("testimonials.{$i}.caption")); ?></h5>
                                <blockquote class="message"><?php echo e(trans("testimonials.{$i}.message")); ?></blockquote>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>