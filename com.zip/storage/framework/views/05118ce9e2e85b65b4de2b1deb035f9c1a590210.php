<li>
    <div class="comment-item" data-id="<?php echo e($comment->id); ?>">
        <div class="avatar">
            <a href="<?php echo e($comment->user->profileLink()); ?>">
                <img src="<?php echo e($comment->user->avatar); ?>" alt="<?php echo e($comment->user->display_name); ?>">
            </a>
        </div>
        <div class="details">
            <div class="meta">
                <strong><a href="<?php echo e($comment->user->profileLink()); ?>"><?php echo e($comment->user->display_name); ?></a></strong>
                <?php if($comment->user->isManager()): ?>
                    <span class="moderator"><?php echo e(trans('discussion.manager')); ?></span>
                <?php endif; ?>
                <?php if($comment->user->isTutor()): ?>
                    <span class="tutor"><?php echo e(trans('discussion.tutor')); ?></span>
                <?php endif; ?>
                <span class="time"><?php echo e($comment->created_at->diffForHumans()); ?></span>
            </div>
            <div class="body">
                <p><?php echo $comment->message; ?></p>
            </div>
            <div class="actions">
                <?php if(Auth::check()): ?>
                <ul class="action-list">
                    <li><a href="javascript:;" id="like-button" title="<?php echo e(trans('discussion.like')); ?>" class="<?php echo e(auth()->user()->likedComment($comment) ? "liked" : ""); ?>"><?php echo e($comment->likes->count()); ?></a></li>
                    <li><a href="javascript:;" id="reply-button" title="<?php echo e(trans('discussion.reply')); ?>"><i class="fa fa-btn fa-reply"></i></a></li>
                    <li class="liked-users animated bounceIn"></li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
        <?php if($comment->children): ?>
        <?php if ( ! (isset($no_children))): ?>
        <ul class="comments-list">
            <?php echo $__env->renderEach('discussion.comment-list', $comment->children, 'comment'); ?>
        </ul>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</li>