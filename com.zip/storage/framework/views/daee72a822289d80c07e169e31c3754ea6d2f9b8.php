<?php $__env->startSection('title', trans('manage/series.edit_title')); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(url('css/select2.min.css')); ?>">
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/series.edit_title')); ?></h2>
                    <?php echo $__env->make('manage.series.partials.form',[
                        "url" => action('ManageController@updateSeries', ["id" => $series->id]),
                        "button_text" => trans('manage/series.update'),
                        "status" => "edit"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script src="<?php echo e(url('js/select2.min.js')); ?>"></script>
<script>
    $(function () {
        $('#skill-select').select2({

        });

        function deleteDidClick($id) {
            swal({
                title: "<?php echo e(trans('messages.are_you_sure_delete')); ?>",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                confirmButtonText: "<?php echo e(trans('messages.delete_button')); ?>",
                showLoaderOnConfirm: true,
                closeOnConfirm: false
            }, function () {
                $.ajax({
                    url: "<?php echo e(url('manage/series')); ?>/" + $id,
                    type: "DELETE",
                    data: {_token: "<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success: function (data) {
                        swal({title:data.message, type:data.status,timer: 1000,showConfirmButton: false});

                        if (data.status == "success") {
                            setTimeout(function () {
                                window.location.href = "<?php echo e(url('manage/series')); ?>";
                            }, 800);
                        }
                    }
                });
            });
        }

        $('a#delete-btn').click(function () {
            deleteDidClick(<?php echo e($series->id); ?>);
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>