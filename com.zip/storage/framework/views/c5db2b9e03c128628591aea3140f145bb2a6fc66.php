<header class="main-header">
    <?php if(isset($blur)): ?>
        <div class="blurry-container">
            <div class="black-overlay"></div>
            <div class="blurry-background">
                <div class="background-image"></div>
            </div>
        </div>
    <?php endif; ?>
    <nav class="navbar navbar-default" id="main-nav">
        <div class="container">
            <div class="navbar-header">
                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#spark-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->
                <div class="logo">
                    <a class="navbar-brand animated infinite pulse" href="<?php echo e(url('/')); ?>" id="brand-link">
                        <img src="<?php echo e(url('favicon.png')); ?>" alt="Abletive教学视频站" style="height: 100%;">
                    </a>
                </div>
            </div>

            <div class="collapse navbar-collapse" id="spark-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo e(url('/')); ?>"><?php echo e(trans('app/site.title')); ?></a></li>
                </ul>
                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right animated slideInDown">
                    <!-- Authentication Links -->
                    <li class="animated fadeIn"><a href="javascript:;" id="search-btn"><i class="fa fa-search"></i></a></li>
                    <li class="animated fadeIn dropdown">
                        <a href="#"><?php echo e(trans("header/navbar.library")); ?>&nbsp;<i class="fa fa-btn fa-angle-double-down"></i></a>

                        <ul class="dropdown-menu animated fadeInRight" role="menu">
                            <li><a href="<?php echo e(url('series')); ?>"><i class="fa fa-btn fa-puzzle-piece"></i> <?php echo e(trans('header/navbar.library_items.series')); ?></a></li>
                            <li><a href="<?php echo e(url('lessons')); ?>"><i class="fa fa-btn fa-tasks"></i> <?php echo e(trans('header/navbar.library_items.catalog')); ?></a></li>
                            <li><a href="<?php echo e(url('tags')); ?>"><i class="fa fa-btn fa-tag"></i> <?php echo e(trans('header/navbar.library_items.tags')); ?></a></li>
                        </ul>
                    </li>
                    <li class="animated fadeIn dropdown">
                        <a href="#"><?php echo e(trans("header/navbar.skills")); ?>&nbsp;<i class="fa fa-btn fa-angle-double-down"></i></a>

                        <ul class="dropdown-menu animated fadeInRight" role="menu">
                            <li>
                                <a href="<?php echo e(url('skills/live')); ?>">
                                    <svg class="ableton-logo" version="1.1" id="ableton-logo"
                                         xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                         x="0px" y="0px" width="23px" height="14px" viewBox="0 0 45 21"
                                         enable-background="new 0 0 45 21" xml:space="preserve">
                                        <g>
                                            <rect width="3" height="21"></rect>
                                            <rect x="6" width="3" height="21"></rect>
                                            <rect x="12" width="3" height="21"></rect>
                                            <rect x="18" width="3" height="21"></rect>
                                            <g>
                                                <rect x="24" y="18" width="21" height="3"></rect>
                                                <rect x="24" y="12" width="21" height="3"></rect>
                                                <rect x="24" y="6" width="21" height="3"></rect>
                                                <rect x="24" width="21" height="3"></rect>
                                            </g>
                                        </g>
                                    </svg>
                                    Ableton Live
                                </a>
                            </li>
                            <li><a href="<?php echo e(url('skills/launchpad')); ?>"><i class="fa fa-btn fa-th"></i>Launchpad</a></li>
                            <li><a href="<?php echo e(url('skills/produce')); ?>"><i class="fa fa-btn fa-music"></i> <?php echo e(trans('header/navbar.skill_items.music_production')); ?></a></li>
                            <li><a href="<?php echo e(url('skills/dj')); ?>"><i class="fa fa-btn fa-headphones"></i> DJ</a></li>
                            <li><a href="<?php echo e(url('skills/controller')); ?>"><i class="fa fa-btn fa-gamepad"></i> <?php echo e(trans('header/navbar.skill_items.other')); ?></a></li>
                        </ul>
                    </li>
                    <li class="animated fadeIn dropdown">
                        <a href="#"><?php echo e(trans("header/navbar.account")); ?>&nbsp;<i class="fa fa-btn fa-angle-double-down"></i></a>

                        <ul class="dropdown-menu animated fadeInRight" role="menu">
                            <li><a href="<?php echo e(url('language/') . '/'); ?><?php echo e(app()->getLocale() == "zh" ? "en" : "zh"); ?>"><i class="fa fa-btn fa-language"></i> <?php echo e(trans('app/site.menu.language')); ?></a></li>
                            <?php if(auth()->guest()): ?>
                                <li><a href="javascript:;" id="login-btn"><i class="fa fa-btn fa-plug"></i> <?php echo e(trans('header/navbar.account_items.login')); ?></a></li>
                                <li><a href="<?php echo e(url('register')); ?>"><i class="fa fa-btn fa-plus"></i> <?php echo e(trans('header/navbar.account_items.register')); ?></a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(auth()->user()->profileLink()); ?>"><i class="fa fa-btn fa-street-view"></i> <?php echo e(str_limit(auth()->user()->display_name, 12)); ?></a></li>
                                <li class="divider"></li>
                                <?php if(auth()->user()->isManager()): ?>
                                <li><a href="<?php echo e(url('manage')); ?>"><i class="fa fa-btn fa-cogs"></i> <?php echo e(trans('header/navbar.account_items.manage')); ?></a></li>
                                <li><a href="<?php echo e(url('publish/lessons')); ?>"><i class="fa fa-btn fa-list-alt"></i> <?php echo e(trans('header/navbar.account_items.publish')); ?></a></li>
                                <li class="divider"></li>
                                <?php elseif(auth()->user()->isTutor()): ?>
                                <li><a href="<?php echo e(url('lesson/create')); ?>"><i class="fa fa-btn fa-list-alt"></i> <?php echo e(trans('header/navbar.account_items.publish')); ?></a></li>
                                <li class="divider"></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(url('settings')); ?>"><i class="fa fa-btn fa-sliders"></i> <?php echo e(trans('header/navbar.account_items.settings')); ?></a></li>
                                <li><a href="<?php echo e(url('profile')); ?>"><i class="fa fa-btn fa-dashboard"></i> <?php echo e(trans('header/navbar.account_items.profile')); ?></a></li>
                                <li><a href="<?php echo e(url('laters')); ?>"><i class="fa fa-btn fa-clock-o"></i> <?php echo e(trans('header/navbar.account_items.watch_laters')); ?></a></li>
                                <li><a href="<?php echo e(url('favorites')); ?>"><i class="fa fa-btn fa-heart"></i> <?php echo e(trans('header/navbar.account_items.favorites')); ?></a></li>
                                <li><a href="<?php echo e(url('history')); ?>"><i class="fa fa-btn fa-calendar-check-o"></i> <?php echo e(trans('header/navbar.account_items.history')); ?></a></li>
                                <li class="divider"></li>
                                <li><a href="javascript:;" id="logout-btn"><i class="fa fa-btn fa-power-off"></i> <?php echo e(trans('header/navbar.account_items.logout')); ?></a></li>
                            <?php endif; ?>
                                <li class="divider"></li>
                                <li><a href="http://abletive.com"><i class="fa fa-btn fa-fort-awesome"></i> <?php echo e(trans('header/navbar.account_items.back_to_abletive')); ?></a></li>
                        </ul>
                    </li>
                    <?php if ( ! (auth()->guest())): ?>
                        <li class="animated rotateIn">
                            <img class="img-circle avatar" src="<?php echo e(auth()->user()->avatar); ?>" alt="">
                        </li>
                    <?php endif; ?>
                </ul>
                <?php if ( ! (auth()->guest())): ?>
                <!-- Experience -->
                <div class="experience animated slideInRight">
                    <span class="xp">XP: </span>
                    <span id="user-experience" title="<?php echo e(trans('header/navbar.experience')); ?>"><?php echo e(auth()->user()->experience); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <?php echo $__env->yieldContent('header-content'); ?>
    <?php echo $__env->yieldContent('banner'); ?>
</header>
<?php echo $__env->make('layouts.partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>