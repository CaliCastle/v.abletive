<?php if(count($tags)): ?><li class="divider" data-content="<?php echo e(trans('tags.title')); ?>"></li><?php endif; ?>
<?php foreach($tags as $tag): ?>
<li class="tag-item item">
    <a href="<?php echo e($tag->link()); ?>">
        <h3><?php echo e($tag->name); ?></h3>
    </a>
</li>
<?php endforeach; ?>