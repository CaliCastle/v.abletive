<div class="series">
    <span class="series-difficulty"><?php echo e(trans('app/site.features.difficulty.' . $series->difficulty)); ?></span>
    <?php if($series->recentlyPublished()): ?>
    <span class="series-status"><?php echo e(trans('app/site.features.status.new')); ?></span>
    <?php elseif($series->recentlyUpdated()): ?>
    <span class="series-status"><?php echo e(trans('app/site.features.status.updated')); ?></span>
    <?php endif; ?>
    <div class="series-thumbnail">
        <a href="<?php echo e($series->link()); ?>">
            <img src="<?php echo e($series->thumbnail); ?>" alt="<?php echo e($series->title); ?>">
            <div class="series-overlay">
                <i class="fa fa-play-circle"></i>
            </div>
        </a>
    </div>
    <div class="series-details">
        <h3 class="series-title"><a href="<?php echo e($series->link()); ?>"><?php echo e(str_limit($series->title, 40)); ?></a></h3>
        <div class="series-count">
            <h3><?php echo e($series->lessons->count()); ?></h3>
            <span><?php echo e(trans('app/site.features.videos')); ?></span>
        </div>
    </div>
</div>