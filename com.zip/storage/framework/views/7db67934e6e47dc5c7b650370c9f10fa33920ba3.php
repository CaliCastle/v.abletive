<?php $__env->startSection('title', trans('profile.title', ["name" => $user->display_name])); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="banner">
                <div class="col-lg-10">
                    <div class="avatar animated animated-delay1 fadeInRight">
                        <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->display_name); ?>">
                    </div>
                    <div class="meta animated animated-delay4 fadeInUp">
                        <h2 class="name"><?php echo e($user->display_name); ?></h2>
                        <p class="description"><?php echo e($user->description); ?></p>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->id == $user->id): ?>
                                <a href="<?php echo e(url('settings')); ?>" class="edit-button"><?php echo e(trans('profile.edit')); ?></a>
                                <a href="<?php echo e(url('update-account')); ?>" class="edit-button"><i class="fa fa-btn fa-repeat"></i> <?php echo e(trans('profile.update')); ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="experience animated animated-delay6 bounceInRight">
                        <span class="number"><?php echo e($user->experience); ?></span>
                        <span><?php echo e(trans('profile.xp')); ?></span>
                        <b><?php echo e($user->level()); ?></b>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                <div class="col-lg-12">
                    <ul class="status">
                        <li class="animated animated-delay5 fadeInLeft">
                            <span><i class="fa fa-btn fa-archive"></i> <?php echo trans('profile.member-since', ['date' => $user->registered_at->diffForHumans()]); ?></span>
                        </li>
                        <li class="animated animated-delay8 fadeInLeft"><span><i class="fa fa-btn fa-street-view"></i> <?php echo $user->expired() ? trans('profile.membership-expired') : trans('profile.membership-since', ['date' => $user->expired_at->diffForHumans()]); ?></span></li>
                        <li class="animated animated-delay10 fadeInLeft">
                            <span><i class="fa fa-btn fa-heart"></i> <strong><?php echo e($user->favoriteLessons->count()); ?></strong>&nbsp;<?php echo e(trans('profile.favorites')); ?></span>
                        </li>
                        <li class="animated animated-delay11 fadeInLeft">
                            <span><i class="fa fa-btn fa-check"></i> <?php echo trans('profile.completed', ["number" => $user->watchedLessons->count()]); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container main-content">
        <section class="discussion">
            <div class="row">
                <h2 class="big-heading">
                    <span class="subtitle"><?php echo e(trans('profile.callout')); ?></span>
                    <span><?php echo e(trans('profile.discussion', ["name" => $user->display_name])); ?></span>
                </h2>
            </div>
            <div class="row">
                <ul class="comments-list">
                <?php $__empty_1 = true; foreach($user->profileComments() as $comment): $__empty_1 = false; ?>
                        <?php echo $__env->make('discussion.profile-comments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; if ($__empty_1): ?>
                    <h4 class="empty"><?php echo e(trans('profile.empty-discussion')); ?></h4>
                <?php endif; ?>
                </ul>
            </div>
        </section>
        <?php if($user->isTutor() || $user->isManager()): ?>
        <section class="lesson">
            <div class="row">
                <h2 class="big-heading">
                    <span><?php echo e(trans('profile.lesson', ["name" => $user->display_name])); ?></span>
                </h2>
            </div>
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1">
                    <?php echo $__env->make('series.partials.profile-lessons', ["lessons" => $user->profileLessons()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </section>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>