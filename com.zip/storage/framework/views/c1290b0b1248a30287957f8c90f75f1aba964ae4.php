<?php $__env->startSection('title', trans('manage/skills.edit_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/skills.title')); ?></h2>
                    <div class="row">
                        <form action="<?php echo e(action('ManageController@updateSkill', ["id" => $skill->id])); ?>" method="POST" class="setting-form">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label><?php echo e(trans('manage/skills.name')); ?></label>
                                <input class="form-control" type="text" name="name" value="<?php echo e($skill->name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label><?php echo e(trans('manage/skills.thumbnail')); ?></label>
                                <input class="form-control" type="text" name="thumbnail" value="<?php echo e($skill->thumbnail); ?>" required>
                            </div>
                            <div class="form-group">
                                <label><?php echo e(trans('manage/skills.description')); ?></label>
                                <textarea class="form-control" name="description"><?php echo $skill->description; ?></textarea>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-block btn-primary" value="<?php echo e(trans('manage/skills.update')); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>