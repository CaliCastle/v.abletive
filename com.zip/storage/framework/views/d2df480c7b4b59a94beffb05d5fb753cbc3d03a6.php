<ul class="lesson-list lesson-list--special animated animated-delay2 fadeIn">
    <?php $__empty_1 = true; foreach($lessons as $lesson): $__empty_1 = false; ?>
        <li class="lesson-item<?php echo e(auth()->check() ? auth()->user()->hasWatched($lesson) ? " lesson--completed" : "" : ""); ?> animated fadeInUp" video-id="<?php echo e($lesson->id); ?>">
            <span class="status"><a href="<?php echo e(url('history')); ?>"><i class="fa fa-check-circle"></i></a></span>
            <span class="title">
                <a href="<?php echo e($lesson->series->link()); ?>"><?php echo e($lesson->series->title); ?></a>
                <a href="<?php echo e($lesson->link()); ?>"><?php echo e($lesson->title); ?></a>
            </span>
            <span class="length"><?php echo e($lesson->duration); ?></span>
            <?php if ( ! (Auth::guest())): ?>
                <span class="watch-later">
                                    <a href="javascript:;" id="watch-later-btn-icon" title="<?php echo e(trans('series.watch-later')); ?>"><i class="fa fa-clock-o"></i></a>
                                </span>
            <?php endif; ?>
        </li>
    <?php endforeach; if ($__empty_1): ?>
        <h2 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('lessons.lesson')])); ?></h2>
    <?php endif; ?>
</ul>