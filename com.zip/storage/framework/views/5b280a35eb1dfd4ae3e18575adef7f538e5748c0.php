<?php echo $__env->make('search.series-results', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('search.lessons-results', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('search.users-results', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('search.tags-results', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>