<section class="level-up">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="callout col-lg-4 col-lg-offset-8">
                <h3><?php echo e(trans('app/site.level-up.heading')); ?></h3>
                <p><?php echo e(trans('app/site.level-up.paragraph')); ?></p>
                <p><?php echo e(trans('app/site.level-up.paragraph-2')); ?></p>
            </div>
        </div>
    </div>
</section>