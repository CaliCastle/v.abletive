<?php $__env->startSection('title', trans('setting/level.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('profile.settings.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('setting/level.title')); ?></h2>
                    <h2 class="big-heading">
                        <span class="subtitle"><?php echo e(auth()->user()->level()); ?></span>
                        <span><?php echo e(trans('setting/level.your-xp', ['xp' => auth()->user()->experience])); ?></span>
                    </h2>
                    <div class="xp-table">
                        <div class="row">
                            <div class="left"><span><?php echo e(trans('setting/level.level-name')); ?></span></div>
                            <div class="right"><span><?php echo e(trans('setting/level.level-xp')); ?></span></div>
                        </div>
                        <?php foreach($levels as $level): ?>
                            <div class="row<?php echo e($level->name === auth()->user()->level() ? " active" : ""); ?>">
                                <div class="left">
                                    <span><?php echo e(trans('app/levels.' . $level->name)); ?></span>
                                </div>
                                <div class="right">
                                    <span><?php echo e(number_format($level->experience)); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>