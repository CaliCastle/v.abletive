<?php $__env->startSection('title', trans('setting/notification.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('profile.settings.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('setting/notification.title')); ?></h2>
                    <form action="<?php echo e(url('settings/notification')); ?>/<?php echo e(auth()->user()->subscribed() ? "unsubscribe" : "subscribe"); ?>" method="POST" class="setting-form">
                        <div class="form-group">
                            <blockquote><?php echo e(auth()->user()->subscribed() ? trans('setting/notification.explanation') : trans('setting/notification.promotion')); ?></blockquote>
                        </div>
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input type="submit" class="btn btn-block btn-<?php echo e(auth()->user()->subscribed() ? "danger" : "primary"); ?>"
                                   value="<?php echo e(auth()->user()->subscribed() ? trans('setting/notification.unsubscribe') : trans('setting/notification.subscribe')); ?>">
                        </div>
                    </form>
                    <?php if(auth()->user()->subscribed()): ?>
                        <div class="row">
                            <h2 class="big-heading">
                                <span><?php echo e(trans('setting/notification.my_notifs')); ?></span>
                            </h2>
                            <ul class="subscription-list">
                                <?php $__empty_1 = true; foreach(auth()->user()->notifications as $series): $__empty_1 = false; ?>
                                <li>
                                    <form action="<?php echo e(url('series/cancel')); ?>/<?php echo e($series->id); ?>" method="POST" class="setting-form">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group subscription-group">
                                            <a target="_blank" href="<?php echo e($series->link()); ?>" class="subscription-lesson"><?php echo e($series->title); ?></a>
                                            <input class="btn btn-block btn-danger" type="submit" value="<?php echo e(trans('setting/notification.cancel')); ?>">
                                        </div>
                                    </form>
                                </li>
                                <?php endforeach; if ($__empty_1): ?>
                                    <h2 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('setting/notification.subscription')])); ?></h2>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>