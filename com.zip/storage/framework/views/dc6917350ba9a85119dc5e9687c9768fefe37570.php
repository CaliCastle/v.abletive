<?php $__env->startSection('title', trans('setting/subscription.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('profile.settings.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('setting/subscription.title')); ?></h2>
                    <form action="" method="POST" class="setting-form">
                        <div class="form-group">
                            <label><?php echo auth()->user()->expired() ? trans('profile.membership-expired') : trans('profile.membership-since', ["date" => auth()->user()->expired_at->diffForHumans()]); ?></label>
                        </div>
                        <div class="form-group">
                            <p><?php echo trans('setting/subscription.other', ["link" => "http://abletive.com/author/" . auth()->user()->user_id . "?tab=membership"]); ?></p>
                            <p><?php echo e(trans('setting/account.sync-message')); ?> <a href="<?php echo e(url('update-account')); ?>"><?php echo e(trans('setting/account.sync-link')); ?></a></p>
                        </div>
                    </form>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>