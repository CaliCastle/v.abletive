<div class="comment-actions">
    <div class="myself">
        <img src="<?php echo e(auth()->check() ? auth()->user()->avatar : url('assets/images/noavatar.png')); ?>" alt="" class="avatar">
    </div>
    <div class="reply">
        <?php if(Auth::guest()): ?>
            <div class="textarea guest">
                <h3><?php echo trans('discussion.login-message'); ?></h3>
            </div>
        <?php else: ?>
            <div id="reply-textarea" class="textarea" contenteditable data-placeholder="<?php echo e(trans('discussion.placeholder')); ?>"></div>
            <form action="<?php echo e(url('comments/upload_image')); ?>" method="POST" class="dropzone" id="dropzone"><?php echo csrf_field(); ?></form>
            <div class="reply-actions">
                <a href="javascript:;" id="insert-timecode"><i class="fa fa-btn fa-clock-o"></i><?php echo e(trans('discussion.insert')); ?></a>
                <a href="javascript:;" id="insert-image"><i class="fa fa-btn fa-image"></i><?php echo e(trans('discussion.insert_image')); ?></a>
                <a href="javascript:;" id="cancel-reply"><i class="fa fa-btn fa-times"></i><?php echo e(trans('discussion.cancel')); ?></a>
            </div>
            <div class="reply-button">
                <a href="javascript:;" id="reply-submit"><?php echo e(trans('discussion.submit')); ?></a>
            </div>
        <?php endif; ?>
    </div>
</div>