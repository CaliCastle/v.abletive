<nav class="main-nav">
    <ul>
        <li<?php echo e(request()->getRequestUri() == "/manage" ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('manage')); ?>"><?php echo e(trans('manage/sidebar.index')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(str_contains(request()->getRequestUri(),"/manage/series") ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('manage/series')); ?>"><?php echo e(trans('manage/sidebar.series')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(str_contains(request()->getRequestUri(), "/manage/lessons") ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('manage/lessons')); ?>"><?php echo e(trans('manage/sidebar.lessons')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(str_contains(request()->getRequestUri(), "/manage/skills") ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('manage/skills')); ?>"><?php echo e(trans('manage/sidebar.skills')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(str_contains(request()->getRequestUri(), "/manage/users") ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('manage/users')); ?>"><?php echo e(trans('manage/sidebar.users')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(str_contains(request()->getRequestUri(), "/manage/comments") ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('manage/comments')); ?>"><?php echo e(trans('manage/sidebar.comments')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
    </ul>
</nav>