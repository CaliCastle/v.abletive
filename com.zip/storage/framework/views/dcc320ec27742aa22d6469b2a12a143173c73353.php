<?php $__env->startSection('title', strip_tags(trans('app/site.503'))); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="row">
                <div class="nothing-found text-center">
                    <h1><i class="fa fa-toggle-on"></i></h1>
                    <h1><?php echo trans('app/site.503'); ?></h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>