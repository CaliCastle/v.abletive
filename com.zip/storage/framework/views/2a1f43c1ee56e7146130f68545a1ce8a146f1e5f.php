<?php $__env->startSection('title', trans('manage/lessons.edit_title')); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(url('css/select2.min.css')); ?>">
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/lessons.edit_title')); ?></h2>
                    <?php echo $__env->make('manage.lesson.partials.form', [
                       "url" => action('ManageController@updateLesson', ["id" => $lesson->id]),
                       "button_text" => trans('manage/lessons.edit_button'),
                       "type" => "edit"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script src="<?php echo e(url('js/select2.min.js')); ?>"></script>
<script>
    $(function () {
        $('#xp-select').select2();
        $('#series-select').select2();
        $('#tag-select').select2({
            tags: true,
            tokenSeparators: [',', ' ']
        });


        function deleteDidClick($id) {
            swal({
                title: "<?php echo e(trans('messages.are_you_sure_delete')); ?>",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                confirmButtonText: "<?php echo e(trans('messages.delete_button')); ?>",
                showLoaderOnConfirm: true,
                closeOnConfirm: false
            }, function () {
                $.ajax({
                    url: "<?php echo e(url('manage/lessons')); ?>/" + $id,
                    type: "DELETE",
                    data: {_token: "<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success: function (data) {
                        swal({title:data.message, type:data.status,timer: 1000,showConfirmButton: false});

                        setTimeout(function () {
                            if (data.status == "success") {
                                window.location.href = "<?php echo e(url('manage/lessons')); ?>";
                            }
                        }, 1000);
                    }
                });
            });
        }

        $('a#delete-btn').click(function () {
            deleteDidClick(<?php echo e($lesson->id); ?>);
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>