<dl>
<?php $__empty_1 = true; foreach($users as $user): $__empty_1 = false; ?>
    <dt><img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->display_name); ?>"></dt>
<?php endforeach; if ($__empty_1): ?>
<?php endif; ?>
</dl>