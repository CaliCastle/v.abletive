<?php $__env->startSection('title', $lesson->title . ' - ' . $series->title); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(url('css/dropzone.css')); ?>">
<?php $__env->appendSection(); ?>

<?php $__env->startSection('scripts.header'); ?>
<script src="<?php echo e(url('js/video.min.js')); ?>"></script>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('series.lessons.partials.video-box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="row">
            <?php echo $__env->make('series.lessons.partials.series-lessons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <section id="discussions" class="discussions">
        <div class="container">
            <div class="row">
                <h2 class="big-heading">
                    <span class="subtitle"><?php echo e(trans('lessons.discussion.heading')); ?></span>
                    <span><?php echo e(trans('lessons.discussion.title')); ?></span>
                </h2>
            </div>
            <div class="row">
                <div class="comments-wrap">
                    <?php echo $__env->make('series.lessons.partials.comment-actions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php if($lesson->hasHotComments()): ?>
                    <div class="row">
                        <h2 class="big-heading">
                            <span><i class="fa fa-btn fa-fire"></i> <?php echo e(trans('discussion.hots')); ?></span>
                        </h2>
                    </div>
                    <div class="row">
                        <ul class="hot-comments-list">
                            <?php foreach($lesson->hotComments() as $hotComment): ?>
                                <?php echo $__env->make('discussion.comment-list', ["comment" => $hotComment, "no_children" => 'true'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <div class="row">
                        <h2 class="big-heading">
                            <span><i class="fa fa-chevron-down"></i></span>
                        </h2>
                    </div>
                    <div class="row">
                        <ul class="comments-list">
                            <?php $__empty_1 = true; foreach($comments as $comment): $__empty_1 = false; ?>
                                <?php echo $__env->make('discussion.comment-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endforeach; if ($__empty_1): ?>
                                <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('discussion.comment')])); ?></h3>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="row text-center">
                        <?php if ( ! ($comments->count() <= $comments->perPage())): ?>
                        <a href="javascript:;" id="load-more-button" class="btn btn-primary" style="padding: 10px 5em;"><?php echo e(trans('discussion.load_more')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="comment-validation" style="display: none;">
        <h2 class="animated fadeInDown"><?php echo e(trans('discussion.validation')); ?></h2>
        <div class="validate animated animated-delay4 bounceIn" id="flip-validation"></div>
        <a href="javascript:;" id="submit-validation" class="animated animated-delay2 fadeInUp"><?php echo e(trans('messages.confirm_button')); ?></a>
        <?php /*<a href="javascript:;" id="cancel-validation" class="animated animated-delay2 fadeInUp"><?php echo e(trans('messages.cancel_button')); ?></a>*/ ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script src="<?php echo e(url('js/dropzone.js')); ?>"></script>
<script src="<?php echo e(url('js/hexaflip.js')); ?>"></script>
<script>
    $(function () {
        var $reply_area = $($('#reply-textarea')[0]);
        var $parent_id = 0;
        var $_token = "<?php echo e(csrf_token()); ?>";
        var $is_submitting = false;
        var $submit_button = $('a#reply-submit');
        var $current_page = 1;
        var $is_loading = false;
        var $loading_text = "<?php echo e(trans('discussion.load_more')); ?>";
        var $valiadtion = $('.comment-validation')[0];
        var $validateCubes;

        <?php if(!$lesson->needSubscription()): ?>
        var player = videojs('abletive-video', { "aspectRatio":"160:95", "playbackRates": [0.5, 0.75, 1, 1.5, 2, 3] }, function () {

            <?php if(request()->query('autoplay')): ?>
            this.play();
            <?php endif; ?>

            <?php if ( ! (Auth::guest())): ?>
            <?php if ( ! (auth()->user()->hasWatched($lesson))): ?>
            this.on('ended', function () {
                // When the video completed playing
                $.ajax({
                    url: "<?php echo e(url('lessons/completed')); ?>/<?php echo e($lesson->id); ?>",
                    type: "PUT",
                    data: {_token: "<?php echo e(csrf_token()); ?>"},
                    dataType: "json",
                    success: function (data) {
                        showGenieMessage(data.message);
                        $('span#user-experience').html(data.xp);
                        $('span#video-status').html('<i class="fa fa-check-circle"></i> <?php echo e(trans('lessons.status.completed')); ?>');
                        $($('span#video-status').parent()).addClass('completed animated rubberBand');

                        if (data.level_up != "no") {
                            showStatusMessage(data.level_up);
                        }
                    }
                });
            });
            <?php endif; ?>
            <?php endif; ?>
        });
        <?php else: ?>
            <?php if(auth()->check()): ?>
            <?php if(auth()->user()->validSubscription()): ?>
                var player = videojs('abletive-video', { "aspectRatio":"160:95", "playbackRates": [0.5, 0.75, 1, 1.5, 2, 3] }, function () {

                    <?php if(request()->query('autoplay')): ?>
                            this.play();
                    <?php endif; ?>
                            <?php if ( ! (Auth::guest())): ?>
                            <?php if ( ! (auth()->user()->hasWatched($lesson))): ?>
                            this.on('ended', function () {
                        // When the video completed playing
                        $.ajax({
                            url: "<?php echo e(url('lessons/completed')); ?>/<?php echo e($lesson->id); ?>",
                            type: "PUT",
                            data: {_token: "<?php echo e(csrf_token()); ?>"},
                            dataType: "json",
                            success: function (data) {
                                showGenieMessage(data.message);
                                $('span#user-experience').html(data.xp);
                                $('span#video-status').html('<i class="fa fa-check-circle"></i> <?php echo e(trans('lessons.status.completed')); ?>');
                                $($('span#video-status').parent()).addClass('completed animated rubberBand');

                                if (data.level_up != "no") {
                                    showStatusMessage(data.level_up);
                                }
                            }
                        });
                    });
                    <?php endif; ?>
                    <?php endif; ?>
                });
            <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ( ! (Auth::guest())): ?>

        // Dropzone init
        Dropzone.options.dropzone = {
                init: function () {
                    this.on("success", function (file, data) {
                        if (data.status == "ok") {
                            $(data.html).appendTo($($reply_area));
                            $reply_area.trigger('DOMNodeInserted');
                            this.removeFile(file);
                        }
                    })
                },
                paramName: "image",
                maxFileSize: 2,
                maxFiles: 2,
                acceptedFiles: 'image/*',
                dictDefaultMessage: "<?php echo e(trans('messages.upload_message')); ?>",
                dictFileTooBig: "<?php echo e(trans('messages.upload_filesize')); ?>",
                dictInvalidFileType: "<?php echo e(trans('messages.upload_filetype')); ?>",
                dictMaxFilesExceeded: "<?php echo e(trans('messages.upload_files')); ?>"
        };

        var validate_errors = 0,
            makeObject = function(a){
            var o = {};
            for(var i = 0, l = a.length; i < l; i++){
                o['letter' + i] = a;
            }
            return o;
        },
            getSequence = function(a, reverse, random){
                var o = {}, p;
                for(var i = 0, l = a.length; i < l; i++){
                    if(reverse){
                        p = l - i - 1;
                    }else if(random){
                        p = Math.floor(Math.random() * l);
                    }else{
                        p = i;
                    }
                    o['letter' + i] = a[p];
                }
                return o;
            };

        $validateCubes = new HexaFlip(document.getElementById('flip-validation'), makeObject("CALI".split('')),{
            size: 150,
            margin: 12,
            fontSize: 100,
            perspective: 450
        });

        $validateCubes.setValue(getSequence("CALI", false, true));

        $('a#submit-validation').click(function () {
            if (validate_errors >= 3) {
                validate_errors = 0;
                $($valiadtion).fadeOut();
                return false;
            }

            if ($validateCubes.getValue().join('') != "CALI") {
                validate_errors++;
                $validateCubes.setValue(getSequence("CALI", false, true));
            } else {
                $($valiadtion).fadeOut();
                submitComment();
            }
        });

        $($valiadtion).dblclick(function (e) {
            if (e.target == this) {
                $($valiadtion).fadeOut();
            }
        });

        // Watch later actions
        $('a#watch-later-btn').each(function () {
            var el = $(this);
            $(this).click(function () {
                $id = $($(this).parents('ul')[0]).attr('video-id');
                $.ajax({
                    url: "<?php echo e(url('lessons/watch_later')); ?>/" + $id,
                    type: "POST",
                    data: {_token: $_token},
                    dataType: "json",
                    success: function (data) {
                        el.toggleClass('active');
                        swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                    }
                });
            });
        });
        $('a#watch-later-btn-icon').each(function () {
            var el = $(this);
            $(this).click(function () {
                $id = $($(this).parents('li')[0]).attr('video-id');
                $.ajax({
                    url: "<?php echo e(url('lessons/watch_later')); ?>/" + $id,
                    type: "POST",
                    data: {_token: $_token},
                    dataType: "json",
                    success: function (data) {
                        el.toggleClass('active');
                        swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                    }
                });
            });
        });

        // Favorite action
        $('a#favorite-btn').click(function () {
            var el = $(this);
            $id = $($(this).parents('ul')[0]).attr('video-id');
            $.ajax({
                url: "<?php echo e(url('lessons/favorite')); ?>/" + $id,
                type: "POST",
                data: {_token: $_token},
                dataType: "json",
                success: function (data) {
                    el.toggleClass('active');
                    swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                }
            });
        });

        // Series notification
        $('a#series-notify-btn').click(function () {
            var el = $(this);
            $.ajax({
                url: "<?php echo e(url('notify')); ?>/<?php echo e($series->id); ?>",
                type: "POST",
                data: {_token: $_token},
                dataType: "json",
                success: function (data) {
                    el.toggleClass('active');
                    swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                }
            });
        });

        $('a#go-to-discuss').click(function () {
            $('body').animate({
                scrollTop: $('#discussions').offset().top
            }, 800);
        });

        $reply_area.each(function () {
            $(this).bind('DOMNodeInserted', function (e) {
                if ($(e.target).hasClass('textarea')) {
                    $reply_area.attr('data-placeholder', '');
                }
            });
            $(this).keydown(function (e) {
                if ((event.ctrlKey || event.metaKey) && e.which == 13) {
                    event.preventDefault();
                    $('a#reply-submit').trigger('click');
                    console.log('..');
                }
            });
        });

        $('a#insert-timecode').each(function () {
            $(this).click(function () {
                var time = Math.floor(player.currentTime());
                var timecode = '<a id="change-timecode" href="javascript:;" title="<?php echo e(trans('discussion.timecode')); ?>" data-time="' + time + '"><i class="fa fa-btn fa-history"></i></a>';
                $(timecode).appendTo($(this).parent().prev().prev());
                $(this).parent().prev().prev().trigger('DOMNodeInserted');
            });
        });

        $('a#insert-image').click(function () {
            $('#dropzone').toggleClass('show-dropzone');
        });

        function initEvents() {
            $('a#change-timecode').each(function () {
                $(this).click(function () {
                    $('body').animate({
                        scrollTop: $('.video-box').offset().top
                    }, 500);
                    player.currentTime($(this).attr('data-time')).play();
                });
            });
            // Like buttons
            $('a#like-button').each(function () {
                var parentItem = $(this).parents(".comment-item")[0],
                        commentID = $(parentItem).attr('data-id'),
                        commentLikes = $(this).html(),
                        $liked_list = $($($(this).parents('.action-list')[0]).find('.liked-users')[0]);

                $(this).click(function () {
                    if (!$(this).hasClass('liked')) {
                        // Like this
                        var el = $(this);

                        $.ajax({
                            url: "<?php echo e(url('comments/like')); ?>/" + commentID,
                            data: {_token: $_token},
                            dataType: "json",
                            type: "PUT",
                            success: function (data) {
                                if (data.status == "success") {
                                    // Succeeded
                                    commentLikes++;
                                    el.html(commentLikes).addClass('liked');
                                } else {
                                    showGenieMessage(data.message);
                                }
                            }
                        });
                    }
                });

                $(this).mouseenter(function () {
                    if (commentLikes != 0) {
                        // Only load for the ones actually have likes
                        $liked_list.addClass('show');
                        if ($liked_list.html() == "") {
                            // Show the spinner
                            $liked_list.html('<i class="fa fa-spin fa-spinner"></i>');
                            addLikeList($liked_list, commentID);
                        }
                    }
                });

                $(this).mouseleave(function () {
                    $liked_list.removeClass('show');
                });
            });
            // Reply buttons
            $('a#reply-button').each(function () {
                $(this).click(function () {
                    // Reply this
                    var parentItem = $(this).parents(".comment-item")[0],
                            parentNode = $(this).parents(".details")[0],
                            commentID = $(parentItem).attr('data-id');

                    $parent_id = commentID;
                    $(".comment-actions").appendTo($(parentNode)).addClass("replying");
                });
            });

            $('a#cancel-reply').each(function () {
                $(this).click(function () {
                    $(".comment-actions").prependTo($(".comments-wrap")).removeClass("replying");
                    $parent_id = 0;
                });
            });
        }

        $submit_button.on('click', function () {
            $($valiadtion).fadeIn();
        });

        // Load more comments
        $('a#load-more-button').click(function () {
            var $load_more = $("a#load-more-button");
            $load_more.html('<i class="fa fa-spin fa-spinner"></i>"');

            if (!$is_loading) {
                $is_loading = true;
                $.ajax({
                    url: "<?php echo e(url('lessons/' . $lesson->id . '/comments')); ?>/" + $current_page,
                    data: {_token: $_token},
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        $is_loading = false;
                        $load_more.html($loading_text);
                        if (data.html == "") {
                            $($load_more).remove();
                        }
                        $(data.html).appendTo($('ul.comments-list')[0]);
                        $current_page++;

                        initEvents();
                    }
                });
            }
        });

        function submitComment() {
            if ($is_submitting) {
                return false;
            }
            // Submit comment
            $content = $reply_area.html();

            if ($content.trim() == "") {
                return false;
            }

            $is_submitting = true;
            $($submit_button).addClass('disabled');

            $.ajax({
                url: "<?php echo e(action("UserController@submitLessonComment", $lesson->id)); ?>",
                data: {_token: $_token, content: $content, parent_id: $parent_id},
                dataType: "json",
                type: "POST",
                success: function (data){
                    $is_submitting = false;
                    $submit_button.removeClass('disabled');
                    if (data.status == "error") {
                        swal({title:data.message, type:"error",timer: 1500,showConfirmButton: false});
                    } else {
                        showGenieMessage(data.message);
                        addComment($parent_id, data.html);
                    }
                }
            });
        }

        function addComment($parent_id, $html) {
            $no_reulst = $('.comments-list h3');
            if (!$parent_id) {
                if ($no_reulst != null) {
                    $no_reulst.remove();
                }
                $($html).appendTo($('.comments-list')[0]).fadeIn();
            } else {
                var selector = '.comment-item[data-id=' + $parent_id + ']';
                $html = "<ul class=\"comments-list\">" + $html + "</ul>";
                $($html).appendTo($(selector)[0]).fadeIn();

                $('a#cancel-reply').trigger('click');
            }
            $reply_area.html('');
            initEvents();
        }

        function addLikeList($selector, $id) {
            $.ajax({
                url: "<?php echo e(url('comments/like_list')); ?>/" + $id,
                type: "POST",
                data: {_token: $_token},
                dataType: "json",
                success: function (data) {
                    $($selector[0]).html(data.html);
                }
            });
        }

        initEvents();
        <?php endif; ?>
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>