<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e(config('app.site.description')); ?>">
    <meta name="keywords" content="<?php echo e(config('app.site.keywords')); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Cali Castle">
    <meta property="og:title" content="<?php echo e(config('app.site.title')); ?>">
    <meta property="og:url" content="<?php echo e(config('app.site.url')); ?>">

    <link rel="icon" href="<?php echo e(url('favicon.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(url('favicon.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('favicon.png')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.site.separator') . trans('app/site.title')); ?></title>

    <!-- Fonts -->
    <link href="http://fonts.useso.com/css?family=Lato:100,300,400,700" rel='stylesheet' type='text/css'>

    <!-- Styles -->
    <link href="<?php echo e(elixir('assets/styles.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>

    <script src="<?php echo e(url('js/modernizr.custom.js')); ?>"></script>

    <!--[if IE]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <?php echo $__env->yieldContent('scripts.header'); ?>
</head>
<body id="app-layout">
    <div class="search-box">
        <input type="search" id="search-box" name="keyword" placeholder="<?php echo e(trans('messages.search_placeholder')); ?>..." autocomplete="off">
        <div class="search-result-wrap">
            <ul class="search-results"></ul>
        </div>
    </div>
    <div class="search-overlay"></div>

    <div id="root" class="page">
        <?php echo $__env->make('layouts.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.partials.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrap">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.partials.dialogs.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <!-- JavaScripts -->
    <script>
        var searchURL = "<?php echo e(url('search')); ?>/",
            $_token = "<?php echo e(csrf_token()); ?>";
    </script>
    <script src="<?php echo e(elixir('assets/scripts.js')); ?>"></script>
    <script>
        $(function () {
            'use strict';

            <?php if(Auth::check()): ?>
            function logoutDidClick() {
                swal({
                    title: "<?php echo e(trans('app/alert.logout.heading')); ?>",
                    text: "<?php echo e(trans('app/alert.logout.message')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    cancelButtonText: "<?php echo e(trans('app/alert.cancel')); ?>",
                    confirmButtonText: "<?php echo e(trans('app/alert.logout.confirm')); ?>",
                    closeOnConfirm: false
                }, function(){
                    window.location.href = "<?php echo e(url('/logout')); ?>";
                });
            }

            $('a#logout-btn').each(function () {
                $(this).click(function () {
                    logoutDidClick();
                });
            });
        <?php else: ?>
            function loginDidClick() {
                var dialog = document.getElementById("login-dialog"),
                        dlg = new DialogFx( dialog );
                dlg.toggle();
            }

            $('a#login-btn').each(function () {
                $(this).click(function () {
                    loginDidClick();
                });
            });
        <?php endif; ?>
        });

    </script>
    <?php echo $__env->yieldContent('scripts.footer'); ?>
</body>
</html>
