<?php $__env->startSection('title', trans('manage/lessons.create_title')); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(url('css/select2.min.css')); ?>">
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/lessons.create_title')); ?></h2>
                    <?php echo $__env->make('manage.lesson.partials.form', [
                       "url" => url('manage/lessons/create'),
                       "button_text" => trans('manage/lessons.create_button'),
                       "type" => "create"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script src="<?php echo e(url('js/select2.min.js')); ?>"></script>
<script>
    $(function () {
        $('#xp-select').select2();
        $('#series-select').select2();
        $('#tag-select').select2({
            tags: true,
            tokenSeparators: [',', ' ']
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>