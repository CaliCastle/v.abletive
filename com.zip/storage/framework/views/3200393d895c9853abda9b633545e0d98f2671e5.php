<?php if ( ! (Auth::guest())): ?>
<div class="menu-wrap">
    <nav class="menu">
        <div class="profile">
            <img src="<?php echo e(auth()->user()->avatar); ?>" alt="<?php echo e(auth()->user()->display_name); ?>"/>
            <span><a href="<?php echo e(auth()->user()->profileLink()); ?>"><?php echo e(str_limit(auth()->user()->display_name, 20)); ?></a></span>
            <span class="level"><a href="<?php echo e(url('settings/level')); ?>"><?php echo e(auth()->user()->level()); ?></a></span>
        </div>
        <div class="link-list">
            <a href="<?php echo e(url('settings')); ?>"><span><i class="fa fa-btn fa-sliders"></i>&nbsp;<?php echo e(trans('app/site.menu.settings')); ?></span></a>
            <a href="<?php echo e(url('profile')); ?>"><span><i class="fa fa-btn fa-dashboard"></i>&nbsp;<?php echo e(trans('app/site.menu.profile')); ?></span></a>
            <a href="<?php echo e(url('favorites')); ?>"><span><i class="fa fa-btn fa-heart"></i>&nbsp;<?php echo e(trans('app/site.menu.favorites')); ?></span></a>
            <a href="<?php echo e(url('laters')); ?>"><span><i class="fa fa-btn fa-clock-o"></i>&nbsp;<?php echo e(trans('app/site.menu.watch_laters')); ?></span></a>
            <a href="<?php echo e(url('language/') . '/'); ?><?php echo e(app()->getLocale() == "zh" ? "en" : "zh"); ?>"><span><?php echo e(trans('app/site.menu.language')); ?></span></a>
        </div>
        <div class="icon-list">
            <a href="<?php echo e(url('/')); ?>"><i class="fa fa-fw fa-home"></i></a>
            <a href="<?php echo e(url('faq')); ?>"><i class="fa fa-fw fa-question-circle"></i></a>
            <a href="javascript:;" id="logout-btn"><i class="fa fa-fw fa-power-off"></i></a>
        </div>
    </nav>
</div>
<button class="menu-button" id="open-button"><i class="fa fa-fw fa-cog"></i><span>Open Menu</span></button>
<div class="background-overlay animated animated-delay2 fadeInLeft"></div>
<?php $__env->startSection('scripts.footer'); ?>
<script>
    (function () {
        'use strict';

        var bodyEl = document.body,
                content = document.querySelector( '.content-wrap' ),
                openbtn = document.getElementById( 'open-button' ),
                closebtn = document.getElementById( 'close-button' ),
                isOpen = false;

        function init() {
            initEvents();
        }

        function initEvents() {
            openbtn.addEventListener( 'click', toggleMenu );
            if( closebtn ) {
                closebtn.addEventListener( 'click', toggleMenu );
            }

            // close the menu element if the target it´s not the menu element or one of its descendants..
            $($('.background-overlay')[0]).on( 'click', function() {
                if( isOpen ) {
                    toggleMenu();
                }
            } );
        }

        function toggleMenu() {
            if( isOpen ) {
                classie.remove( bodyEl, 'show-menu' );
            }
            else {
                classie.add( bodyEl, 'show-menu' );
            }
            isOpen = !isOpen;
        }

        init();

    })();
</script>
<?php $__env->appendSection(); ?>
<?php endif; ?>