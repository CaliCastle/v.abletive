<section class="video">
    <h1 class="title">
        <?php echo e($episode); ?>. <?php echo e($lesson->title); ?>

        <span class="series-title">
                        <span><?php echo e(trans('lessons.in')); ?></span>
            <a href="<?php echo e($series->link()); ?>"><?php echo e($series->title); ?></a>
                    </span>
    </h1>
    <span class="difficulty"><?php echo e(trans('lessons.difficulty.' . strtolower($series->difficulty))); ?></span>
    <div class="video-box">
        <div class="video-player">
            <?php if($lesson->needSubscription()): ?>
            <?php if(auth()->check()): ?>
            <?php if(auth()->user()->validSubscription()): ?>
            <video id="abletive-video" class="video-js vjs-default-skin" controls preload="auto">
                <source src="<?php echo e($lesson->source); ?>" type='video/mp4' />
                <p class="vjs-no-js">
                    <?php echo e(trans('lessons.video-unsupported')); ?>

                </p>
            </video>
            <?php else: ?>
                <div class="need-subscription">
                    <div class="bg"></div>
                    <div class="info">
                        <h1><?php echo e(trans('messages.subscription_heading')); ?></h1>
                        <h4><?php echo e(trans('messages.subscription_message')); ?></h4>
                        <a href="<?php echo e(url('settings/subscription')); ?>"><?php echo e(trans('messages.subscription_button')); ?></a>
                    </div>
                </div>
            <?php endif; ?>
            <?php else: ?>
                <div class="need-subscription">
                    <div class="bg"></div>
                    <div class="info">
                        <h1><?php echo e(trans('messages.subscription_heading')); ?></h1>
                        <h4><?php echo e(trans('messages.subscription_message')); ?></h4>
                        <a href="<?php echo e(url('settings/subscription')); ?>"><?php echo e(trans('messages.subscription_button')); ?></a>
                    </div>
                </div>
            <?php endif; ?>

            <?php else: ?>
                <video id="abletive-video" class="video-js vjs-default-skin" controls preload="auto">
                    <source src="<?php echo e($lesson->source); ?>" type='video/mp4' />
                    <p class="vjs-no-js">
                        <?php echo e(trans('lessons.video-unsupported')); ?>

                    </p>
                </video>
            <?php endif; ?>
        </div>
        <div class="lesson-navigation">
            <?php if($lesson->hasPrevious()): ?>
                <div class="previous">
                    <a href="<?php echo e($lesson->previousEpisode()->link()); ?>?autoplay=1"><i class="fa fa-angle-left"></i><span><?php echo e($episode - 1); ?>. <?php echo e($lesson->previousEpisode()->title); ?></span></a>
                </div>
            <?php endif; ?>
            <?php if($lesson->hasNext()): ?>
                <div class="next">
                    <a href="<?php echo e($lesson->nextEpisode()->link()); ?>?autoplay=1"><span><?php echo e($episode + 1); ?>. <?php echo e($lesson->nextEpisode()->title); ?></span><i class="fa fa-angle-right"></i></a>
                </div>
            <?php endif; ?>
        </div>
        <div class="video-details">
            <strong class="meta"><?php echo e(trans('lessons.published_on', ["date" => $lesson->published_at->diffForHumans()])); ?></strong>
            <div class="experience">
                <span><?php echo e($lesson->experience); ?> <?php echo e(trans('lessons.xp')); ?></span>
            </div>
            <div class="body">
                <p><?php echo $lesson->description; ?></p>
            </div>
            <ul class="video-tags">
                <?php foreach($lesson->tags as $tag): ?>
                    <li>
                        <a href="<?php echo e($tag->link()); ?>"><?php echo e($tag->name); ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="lesson-tutor">
        <strong><?php echo e(trans('discussion.tutor')); ?>:</strong>
        <a href="<?php echo e($lesson->user->profileLink()); ?>" target="_blank"><img src="<?php echo e($lesson->user->avatar); ?>" alt="<?php echo e($lesson->user->display_name); ?>"></a>
        <div class="details">
            <h4 class="name"><a href="<?php echo e($lesson->user->profileLink()); ?>" target="_blank"><?php echo e($lesson->user->display_name); ?></a></h4>
            <span class="count"><?php echo e(trans('lessons.lessons_count')); ?>: <?php echo e($lesson->user->lessons->count()); ?></span>
        </div>
    </div>
    <div class="action-buttons">
        <ul video-id="<?php echo e($lesson->id); ?>">
            <?php if(Auth::check()): ?>
            <li><a href="javascript:;" class="action-button<?php echo e(auth()->user()->hasWatchLater($lesson) ? " active" : ""); ?>" id="watch-later-btn"><i class="fa fa-btn fa-clock-o"></i> <?php echo e(trans('lessons.watch-later')); ?></a></li>
            <li><a href="javascript:;" class="action-button<?php echo e(auth()->user()->hasFavorite($lesson) ? " active" : ""); ?>" id="favorite-btn"><i class="fa fa-btn fa-heart"></i> <?php echo e(trans('lessons.favorite')); ?></a></li>
            <li><a href="<?php echo e($lesson->downloadLink()); ?>" download target="_blank" class="action-button"><i class="fa fa-btn fa-cloud-download"></i> <?php echo e(trans('lessons.download')); ?></a></li>
            <?php endif; ?>
            <li><a href="javascript:;" id="go-to-discuss" class="action-button"><i class="fa fa-btn fa-comments-o"></i> <?php echo e(trans('lessons.discuss')); ?></a></li>
            <?php if(Auth::check()): ?>
            <li class="status<?php echo e(auth()->user()->hasWatched($lesson) ? " completed" : ""); ?>"><span id="video-status"><i class="fa fa-check-circle"></i> <?php echo e(auth()->user()->hasWatched($lesson) ? trans('lessons.status.completed') : trans('lessons.status.incomplete')); ?></span></li>
            <?php endif; ?>
        </ul>
    </div>
</section>