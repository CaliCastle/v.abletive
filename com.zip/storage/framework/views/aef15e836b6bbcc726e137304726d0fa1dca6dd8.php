<?php $__env->startSection('title', trans('lessons.title')); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="row text-center section">
                <h1 class="heading animated animated-delay1 fadeInUp"><?php echo e(trans('lessons.title')); ?></h1>
                <h3 class="callout animated animated-delay3 fadeInUp"><?php echo e(trans('lessons.subtitle')); ?></h3>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container">
        <div class="row section">
            <div class="col-lg-3">
                <aside class="sidebar">
                    <h3 class="heading-top"><?php echo e(trans('lessons.filters')); ?></h3>
                    <ul class="filter-list">
                        <li>
                            <h4 class="heading"><?php echo e(trans('lessons.difficulties')); ?></h4>
                            <span><a href="<?php echo e(url('lessons/difficulty')); ?>/?s=beginner" class="btn btn-block<?php echo e(request()->query('s') == "beginner" ? " active" : ""); ?>"><?php echo e(trans('lessons.difficulty.beginner')); ?></a></span>
                            <span><a href="<?php echo e(url('lessons/difficulty')); ?>/?s=intermediate" class="btn btn-block<?php echo e(request()->query('s') == "intermediate" ? " active" : ""); ?>"><?php echo e(trans('lessons.difficulty.intermediate')); ?></a></span>
                            <span><a href="<?php echo e(url('lessons/difficulty')); ?>/?s=advanced" class="btn btn-block<?php echo e(request()->query('s') == "advanced" ? " active" : ""); ?>"><?php echo e(trans('lessons.difficulty.advanced')); ?></a></span>
                        </li>
                        <li>
                            <h4 class="heading"><?php echo e(trans('lessons.measurement')); ?></h4>
                            <span><a href="<?php echo e(url('lessons/type')); ?>/?s=hottest" class="btn btn-block<?php echo e(request()->query('s') == "hottest" ? " active" : ""); ?>"><?php echo e(trans('lessons.hottest')); ?></a></span>
                            <span><a href="<?php echo e(url('lessons')); ?>" class="btn btn-block<?php echo e(request()->query('s') == null ? " active" : ""); ?>"><?php echo e(trans('lessons.newest')); ?></a></span>
                            <span><a href="<?php echo e(url('lessons/type')); ?>/?s=oldest" class="btn btn-block<?php echo e(request()->query('s') == "oldest" ? " active" : ""); ?>"><?php echo e(trans('lessons.oldest')); ?></a></span>
                        </li>
                    </ul>
                </aside>
            </div>
            <div class="col-lg-9">
                <?php echo $__env->make('series.partials.lesson-special-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="row section">
                    <div class="text-center">
                        <?php if ( ! (request()->query('s') == "hottest" && url()->current() == url('lessons/type'))): ?>
                        <?php if(url()->current() == url('lessons/difficulty')): ?>
                            <p><?php echo $lessons->appends(['s' => $which])->links(); ?></p>
                        <?php else: ?>
                            <p><?php echo isset($which) ? $lessons->appends(['s' => $which])->links() : $lessons->links(); ?></p>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>