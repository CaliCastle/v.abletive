<?php $__env->startSection('title', trans('manage/index.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/index.title')); ?></h2>
                    <h2 class="big-heading">
                        <span class="subtitle">今日新增用户</span>
                        <span><?php echo e(\App\User::justRegistered()->count()); ?></span>
                    </h2>
                    <h2 class="big-heading">
                        <span class="subtitle">用户总计</span>
                        <span><?php echo e(\App\User::all()->count()); ?></span>
                    </h2>
                    <div class="row">
                        <h2 class="big-heading">
                            <span class="subtitle">总计教程系列</span>
                            <span><?php echo e(\App\Series::all()->count()); ?></span>
                        </h2>
                        <h2 class="big-heading">
                            <span class="subtitle">总计课程</span>
                            <span><?php echo e(\App\Video::all()->count()); ?></span>
                        </h2>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>