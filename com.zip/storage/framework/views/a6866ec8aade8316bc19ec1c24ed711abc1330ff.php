<nav class="main-nav">
    <ul>
        <li<?php echo e(str_contains(request()->getRequestUri(), "/publish/lessons") ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('publish/lessons')); ?>"><?php echo e(trans('manage/sidebar.lessons')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
    </ul>
</nav>