<?php $__env->startSection('title', trans('tags.detail_title', ["name" => $tag->name])); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="tags section">
            <div class="row">
                <h2 class="big-heading">
                    <span class="subtitle"><?php echo e(trans('tags.detail_subtitle', ["count" => $tag->pagedLessons()->total()])); ?></span>
                    <span><?php echo e(trans('tags.detail_title', ["name" => $tag->name])); ?></span>
                </h2>
            </div>
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1">
                    <?php echo $__env->make('series.partials.lesson-special-list', ["lessons" => $tag->pagedLessons()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <p>
                        <?php echo $tag->pagedLessons()->links(); ?>

                    </p>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>