<?php if(count($allSeries)): ?><li class="divider" data-content="<?php echo e(trans('series.title')); ?>"></li><?php endif; ?>
<?php foreach($allSeries as $series): ?>
<li class="series-item item">
    <a href="<?php echo e($series->link()); ?>">
        <img src="<?php echo e($series->thumbnail); ?>" alt="<?php echo e($series->title); ?>">
        <span class="meta">
            <h3><?php echo e($series->title); ?></h3>
            <p><?php echo $series->description; ?></p>
        </span>
    </a>
</li>
<?php endforeach; ?>