<li>
    <div class="comment-item" data-id="<?php echo e($comment->id); ?>">
        <div class="avatar">
            <a href="<?php echo e($comment->user->profileLink()); ?>">
                <img src="<?php echo e($comment->user->avatar); ?>" alt="<?php echo e($comment->user->display_name); ?>">
            </a>
        </div>
        <div class="details">
            <div class="meta">
                <strong><a href="<?php echo e($comment->user->profileLink()); ?>"><?php echo e($comment->user->display_name); ?></a></strong>
                <span class="time"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                <span class="in-series"><?php echo e(trans('profile.in')); ?><a href="<?php echo e($comment->lesson->link()); ?>"><?php echo e($comment->lesson->title); ?></a></span>
            </div>
            <div class="body">
                <p><?php echo $comment->message; ?></p>
            </div>
        </div>
    </div>
</li>