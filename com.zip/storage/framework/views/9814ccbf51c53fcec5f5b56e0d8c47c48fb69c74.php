<?php $__env->startSection('title', isset($keyword) ? trans('manage/series.search-title', ["keyword" => $keyword]) : trans('manage/comments.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(isset($keyword) ? trans('manage/series.search-title', ["keyword" => $keyword]) : trans('manage/comments.title')); ?> <a href="javascript:;" id="search-button"><i class="fa fa-search"></i></a></h2>
                    <div class="row">
                        <?php if(count($comments)): ?>
                            <table class="table table-responsive table-striped">
                                <thead>
                                <tr>
                                    <td><?php echo e(trans('manage/comments.user')); ?></td>
                                    <td><?php echo e(trans('manage/comments.video')); ?></td>
                                    <td><?php echo e(trans('manage/comments.message')); ?></td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($comments as $comment): ?>
                                    <tr data-id="<?php echo e($comment->id); ?>">
                                        <td><a href="<?php echo e($comment->user->profileLink()); ?>"><?php echo e(str_limit($comment->user->display_name, 15)); ?></a></td>
                                        <td><a href=""><?php echo e(str_limit($comment->lesson->title, 20)); ?></a></td>
                                        <td><?php echo e(str_limit($comment->message, 50)); ?></td>
                                        <td><a href="javascript:;" class="btn btn-danger" id="delete-btn"><?php echo e(trans('manage/series.delete_button')); ?></a></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('discussion.comment')])); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script>
    $(function () {
        $("a#search-button").click(function () {
            swal({
                title: "<?php echo e(trans('manage/series.search_box_title')); ?>",
                text: "<?php echo e(trans('manage/series.search_box_message')); ?>:",
                type: "input",
                inputType: "search",
                showCancelButton: true,
                closeOnConfirm: true,
                cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                confirmButtonText: "<?php echo e(trans('messages.search_button')); ?>",
                animation: "slide-from-bottom",
            }, function (inputValue) {
                if (inputValue === false) return;
                if (inputValue === "") {
                    swal.showInputError("...");
                    return;
                }
                window.location.href = "<?php echo e(url('manage/comments/search/')); ?>/" + inputValue;
            });
        });

        $('a#delete-btn').each(function () {
            $(this).click(function () {
                var el = $(this);
                var $id = $($(this).parents('tr')[0]).attr('data-id');
                swal({
                    title: "<?php echo e(trans('messages.are_you_sure_delete')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    cancelButtonText: "<?php echo e(trans('messages.cancel_button')); ?>",
                    confirmButtonText: "<?php echo e(trans('messages.delete_button')); ?>",
                    showLoaderOnConfirm: true,
                    closeOnConfirm: false
                }, function () {
                    $.ajax({
                        url: "<?php echo e(url('manage/comments')); ?>/" + $id,
                        type: "DELETE",
                        data: {_token: "<?php echo e(csrf_token()); ?>"},
                        dataType: "json",
                        success: function (data) {
                            swal({title:data.message, type:data.status,timer: 1000,showConfirmButton: false});
                            var selector = 'tr[data-id="' + $id + '"]';
                            data.status == "success" ? $(selector).fadeOut(1000,function() {$(this).remove()}) : null;
                        }
                    });
                });
            });
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>