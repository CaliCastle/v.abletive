<?php $__env->startSection('title', trans('profile.history_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="timeline">
            <div class="row">
                <h2 class="big-heading">
                    <span class="subtitle"><?php echo e(trans('profile.history_subtitle')); ?></span>
                    <span><?php echo e(trans('profile.history_title')); ?></span>
                </h2>
            </div>
            <?php if(count($lessons)): ?>
            <ul class="cbp_tmtimeline">
                <?php foreach($lessons as $lesson): ?>
                <li class="animated bounceInUp">
                    <time class="cbp_tmtime" datetime="<?php echo e($time_list[$lesson->id]); ?>"><span><?php echo e($time_list[$lesson->id]->diffForHumans()); ?></span> <span><?php echo e($time_list[$lesson->id]->format('H:i')); ?></span></time>
                    <div class="cbp_tmicon"></div>
                    <div class="cbp_tmlabel">
                        <h2><?php echo e(trans('profile.watched')); ?> <a target="_blank" href="<?php echo e($lesson->link()); ?>"><?php echo e($lesson->title); ?></a></h2>
                        <p><?php echo e(trans('profile.from_series')); ?>《<a href="<?php echo e($lesson->series->link()); ?>" target="_blank"><?php echo e($lesson->series->title); ?></a>》. <?php echo e(trans('profile.tutor')); ?> <?php echo e($lesson->user->display_name); ?></p>
                        <p><?php echo e(trans('profile.gain_xp')); ?> <?php echo e($lesson->experience); ?></p>
                        <p><?php echo e(trans('profile.lesson_description')); ?><?php echo e($lesson->description); ?></p>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php else: ?>
            <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('profile.history')])); ?></h3>
            <?php endif; ?>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>