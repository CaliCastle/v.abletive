<?php $__env->startSection('title', trans('setting/account.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('profile.settings.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('setting/account.title')); ?></h2>
                    <form action="<?php echo e(url('settings')); ?>" method="POST" class="setting-form">
                        <?php echo csrf_field(); ?>

                        <div class="form-group<?php echo e($errors->has('slug') ? ' has-error' : ''); ?>">
                            <label for="slug"><?php echo e(trans('setting/account.slug')); ?>:</label>
                            <div class="input-group">
                                <div class="input-group-addon">@</div>
                                <input type="text" class="form-control" name="slug" value="<?php echo e(auth()->user()->slug); ?>">
                            </div>
                            <?php if($errors->has('slug')): ?>
                                <strong class="has-error"><?php echo e($errors->first('slug')); ?></strong>
                            <?php endif; ?>
                            <strong></strong>
                        </div>
                        <div class="form-group<?php echo e($errors->has('display_name') ? ' has-error' : ''); ?>">
                            <label for="display_name"><?php echo e(trans('setting/account.display_name')); ?>:</label>
                            <input class="form-control" type="text" name="display_name" value="<?php echo e(auth()->user()->display_name); ?>">
                            <?php if($errors->has('display_name')): ?>
                                <strong class="has-error"><?php echo e($errors->first('display_name')); ?></strong>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email">Email:</label>
                            <input class="form-control" type="email" name="email" value="<?php echo e(auth()->user()->email); ?>">
                            <?php if($errors->has('email')): ?>
                                <strong class="has-error"><?php echo e($errors->first('email')); ?></strong>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description"><?php echo e(trans('setting/account.description')); ?>:</label>
                            <textarea name="description" class="form-control" id=""><?php echo e(auth()->user()->description); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <strong class="has-error"><?php echo e($errors->first('description')); ?></strong>
                            <?php endif; ?>
                        </div>
                        <div class="form-divider"></div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password"><?php echo e(trans('setting/account.password')); ?>:</label>
                            <b style="display: block;"><?php echo e(trans('setting/account.password-tip')); ?></b>
                            <input class="form-control" type="password" name="password" placeholder="<?php echo e(trans('setting/account.password_placeholder')); ?>">
                            <?php if($errors->has('password')): ?>
                                <strong class="has-error"><?php echo e($errors->first('password')); ?></strong>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('confirm_password') ? ' has-error' : ''); ?>">
                            <input class="form-control" type="password" name="password_confirmation" placeholder="<?php echo e(trans('setting/account.confirm_password')); ?>...">
                        </div>
                        <div class="form-group">
                            <input class="btn btn-block btn-primary" type="submit" value="<?php echo e(trans('setting/account.update')); ?>">
                        </div>
                        <div class="form-group">
                            <p><?php echo trans('setting/account.other', ["link" => "http://abletive.com/author/" . auth()->user()->user_id . "?tab=profile"]); ?></p>
                            <p><?php echo e(trans('setting/account.sync-message')); ?> <a href="<?php echo e(url('update-account')); ?>"><?php echo e(trans('setting/account.sync-link')); ?></a></p>
                        </div>
                    </form>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>