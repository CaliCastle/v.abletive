<?php $__env->startSection('title', trans('series.title')); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="row text-center section">
                <h1 class="heading animated animated-delay1 fadeInUp"><?php echo e(trans('series.title')); ?></h1>
                <h3 class="callout animated animated-delay3 fadeInUp"><?php echo e(trans('series.subtitle')); ?></h3>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container">
        <div class="section">
            <div class="row">
                <div class="series-collection">
                    <?php foreach($allSeries as $series): ?>
                        <?php echo $__env->make('series.partials.series-tiles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>