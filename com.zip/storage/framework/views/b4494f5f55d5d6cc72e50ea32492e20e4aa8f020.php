<?php $__env->startSection('title', $series->title); ?>

<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .background-image {
        background: url("<?php echo e($series->thumbnail); ?>") no-repeat center center;
        background-size: cover;
    }
    header.main-header {
        position: relative;
    }
</style>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="banner">
                <div class="col-lg-3">
                    <div class="series-thumbnail animated animated-delay1 bounceInDown">
                        <img src="<?php echo e($series->thumbnail); ?>" alt="<?php echo e($series->title); ?>">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="series-details">
                        <h1 class="series-heading animated animated-delay3 fadeInUp"><?php echo e($series->title); ?></h1>
                        <p class="series-message animated animated-delay5 fadeInUp">
                            <?php echo $series->description; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                <div class="col-lg-12">
                    <ul class="series-status">
                        <li class="animated animated-delay5 fadeInRight">
                            <span><?php echo e($series->lessons->count()); ?></span> <?php echo e(trans('series.lessons')); ?>

                        </li>
                        <li class="animated animated-delay7 fadeInRight">
                            <span><?php echo e($series->totalMinutes()); ?></span> <?php echo e(trans('series.minutes')); ?>

                        </li>
                        <?php if ( ! (Auth::guest())): ?>
                        <li class="animated animated-delay8 fadeInRight">
                            <?php echo trans('series.complete', ["percent" => auth()->user()->completedPercent($series)]); ?>

                        </li>
                        <?php endif; ?>
                        <li class="experience animated animated-delay8 fadeInLeft">
                            <span><?php echo e($series->totalExperience()); ?></span> <?php echo e(trans('series.xp')); ?>

                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="lessons-wrap">
        <div class="container">
            <div class="row animated animated-delay6 fadeInUp">
                <h2 class="big-heading">
                    <span class="subtitle"><?php echo e(trans('series.series-lessons')); ?></span>
                    <span><?php echo e(trans('series.callout')); ?></span>
                </h2>
            </div>
            <div class="section row grid">
                <div class="col-lg-9">
                    <?php echo $__env->make('series.partials.lesson-list', ["lessons" => $series->lessons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if ( ! ($series->completed)): ?>
                    <p class="development">
                        <?php echo e(trans('series.development')); ?>

                    </p>
                    <?php endif; ?>
                </div>
                <div class="col-lg-3">
                    <div class="lesson-actions">
                        <ul class="actions" series-id="<?php echo e($series->id); ?>">
                            <?php if(Auth::check()): ?>
                            <li class="animated animated-delay8 fadeInRight">
                                <a href="javascript:;" id="series-watch-later-btn" class="action-button<?php echo e(auth()->user()->hasWatchLaterSeries($series) ? " active" : ""); ?>"><i class="fa fa-btn fa-clock-o"></i> <?php echo e(trans('series.watch-later')); ?></a>
                            </li>
                            <li class="animated animated-delay10 fadeInRight">
                                <a href="javascript:;" id="series-favorite-btn" class="action-button<?php echo e(auth()->user()->hasFavoriteSeries($series) ? " active" : ""); ?>"><i class="fa fa-btn fa-heart"></i> <?php echo e(trans('series.favorite')); ?></a>
                            </li>
                            <?php if ( ! ($series->completed)): ?>
                            <li class="animated animated-delay11 fadeInRight">
                                <a href="javascript:;" id="series-notify-btn" class="action-button<?php echo e(auth()->user()->hasNotified($series) ? " active" : ""); ?>"><i class="fa fa-btn fa-envelope"></i> <?php echo e(trans('series.notify')); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php else: ?>
                            <li class="animated animated-delay9 fadeInRight">
                                <a href="javascript:;" id="login-btn" class="action-button"><i class="fa fa-btn fa-smile-o"></i> <?php echo e(trans('messages.login_first')); ?></a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script>
    $(function () {
        var $_token = "<?php echo e(csrf_token()); ?>";
        // Lesson watch later
        $('a#watch-later-btn-icon').each(function () {
            var el = $(this);
            $(this).click(function () {
                $id = $($(this).parents('li')[0]).attr('video-id');
                $.ajax({
                    url: "<?php echo e(url('lessons/watch_later')); ?>/" + $id,
                    type: "POST",
                    data: {_token: $_token},
                    dataType: "json",
                    success: function (data) {
                        el.toggleClass('active');
                        swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                    }
                });
            });
        });
        // Series watch later
        $('a#series-watch-later-btn').click(function () {
            var el = $(this);
            $id = $(el.parents('ul')[0]).attr('series-id');
            var $action = el.hasClass('active');
            var $url = $action ? "<?php echo e(url("series/unwatch_later")); ?>/" : "<?php echo e(url('series/watch_later')); ?>/";
            $.ajax({
                url: $url + $id,
                type: "POST",
                data: {_token: $_token},
                dataType: "json",
                success: function (data) {
                    el.toggleClass('active');
                    swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                }
            });
        });
        // Series favorite
        $('a#series-favorite-btn').click(function () {
            var el = $(this);
            $id = $(el.parents('ul')[0]).attr('series-id');
            var $action = el.hasClass('active');
            var $url = $action ? "<?php echo e(url("series/unfavorite")); ?>/" : "<?php echo e(url('series/favorite')); ?>/";
            $.ajax({
                url: $url + $id,
                type: "POST",
                data: {_token: $_token},
                dataType: "json",
                success: function (data) {
                    el.toggleClass('active');
                    swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                }
            });
        });
        // Series notification
        $('a#series-notify-btn').click(function () {
            var el = $(this);
            $.ajax({
                url: "<?php echo e(url('notify')); ?>/<?php echo e($series->id); ?>",
                type: "POST",
                data: {_token: $_token},
                dataType: "json",
                success: function (data) {
                    el.toggleClass('active');
                    swal({title:data.message, type:"success",timer: 1500,showConfirmButton: false});
                }
            });
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>