<?php $__env->startSection('title', trans('manage/skills.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/skills.title')); ?></h2>
                    <div class="row">
                        <?php if(count($skills)): ?>
                            <table class="table table-striped table-responsive">
                                <thead>
                                <tr>
                                    <td><?php echo e(trans('manage/skills.name')); ?></td>
                                    <td><?php echo e(trans('manage/skills.series')); ?></td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($skills as $skill): ?>
                                    <tr>
                                        <td><?php echo e(trans('skills.' . $skill->name)); ?></td>
                                        <td><?php echo e($skill->series->count()); ?></td>
                                        <td><a href="<?php echo e(action('ManageController@showEditSkill', ["id" => $skill->id])); ?>" class="btn btn-primary"><?php echo e(trans('manage/skills.edit')); ?></a></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('skills.skill')])); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>