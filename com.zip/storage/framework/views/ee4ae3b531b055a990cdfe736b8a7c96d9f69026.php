<ul class="lesson-list lesson-list--numbered animated animated-delay7 fadeIn">
    <?php $__empty_1 = true; foreach($lessons as $lesson): $__empty_1 = false; ?>
        <li class="lesson-item<?php echo e(auth()->check() ? auth()->user()->hasWatched($lesson) ? " lesson--completed" : "" : ""); ?> animated fadeInUp" video-id="<?php echo e($lesson->id); ?>">
            <span class="status"><i class="fa fa-check-circle"></i></span>
                                <span class="title"><a href="<?php echo e($lesson->link()); ?>"><?php echo e($lesson->title); ?>

                                        <?php echo $lesson->recentlyPublished() ? '<span class="new">' . trans('series.new') . '!</span>' : ''; ?></a></span>
            <span class="length"><?php echo e($lesson->created_at->diffForHumans()); ?></span>
        </li>
    <?php endforeach; if ($__empty_1): ?>
        <h2 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('lessons.lesson')])); ?></h2>
    <?php endif; ?>
</ul>