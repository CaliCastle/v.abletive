<form action="<?php echo e($url); ?>" method="POST" class="setting-form">
    <?php echo csrf_field(); ?>

    <div class="form-group<?php echo e($errors->has('title') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/series.create.title')); ?>:</label>
        <input type="text" class="form-control" name="title" value="<?php echo e(old('title') ? old('title') : $series->title); ?>">
        <?php if($errors->has('title')): ?>
            <strong class="has-error"><?php echo e($errors->first('title')); ?></>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('slug') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/series.create.slug')); ?>:</label>
        <input type="text" class="form-control" name="slug" value="<?php echo e(old('slug') ? old('slug') : $series->slug); ?>">
        <?php if($errors->has('slug')): ?>
            <strong class="has-error"><?php echo e($errors->first('slug')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('difficulty') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/series.create.difficulty')); ?>:</label>
        <div class="radio">
            <input type="radio" name="difficulty" value="Beginner"<?php echo e($series->difficulty == "Beginner" ? " checked" : ''); ?>><?php echo e(trans('lessons.difficulty.beginner')); ?>

        </div>
        <div class="radio">
            <input type="radio" name="difficulty" value="Intermediate"<?php echo e($series->difficulty == "Intermediate" ? " checked" : ''); ?>><?php echo e(trans('lessons.difficulty.intermediate')); ?>

        </div>
        <div class="radio">
            <input type="radio" name="difficulty" value="Advanced"<?php echo e($series->difficulty == "Advanced" ? " checked" : ''); ?>><?php echo e(trans('lessons.difficulty.advanced')); ?>

        </div>
        <?php if($errors->has('difficulty')): ?>
            <strong class="has-error"><?php echo e($errors->first('difficulty')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('thumbnail') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/series.create.thumbnail')); ?>:</label>
        <input type="text" class="form-control" name="thumbnail" value="<?php echo e(old('thumbnail') ? old('thumbnail') : $series->thumbnail); ?>">
        <?php if($errors->has('thumbnail')): ?>
            <strong class="has-error"><?php echo e($errors->first('thumbnail')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('description') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/series.create.description')); ?>:</label>
        <textarea name="description" class="form-control"><?php echo e(old('description') ? old('description') : $series->description); ?></textarea>
        <?php if($errors->has('description')): ?>
            <strong class="has-error"><?php echo e($errors->first('description')); ?></strong>
        <?php endif; ?>
    </div>
    <div class="form-group<?php echo e($errors->has('skills') ? " has-error" : ""); ?>">
        <label><?php echo e(trans('manage/series.create.skill')); ?>:</label>
        <select name="skills[]" id="skill-select" class="form-control" multiple>
            <?php foreach(\App\Skill::all() as $skill): ?>
                <option value="<?php echo e($skill->id); ?>"<?php echo e(array_has($series->skills()->lists('id', 'id')->toArray(), $skill->id) ? " selected" : ""); ?>><?php echo e(trans('skills.' . $skill->name)); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <div class="checkbox">
            <input type="checkbox" name="published"<?php echo e($series->published ? " checked" : ""); ?>><?php echo e(trans('manage/series.publish_now')); ?>

        </div>
    </div>
    <?php if(isset($status)): ?>
    <div class="form-group">
        <div class="checkbox">
            <input type="checkbox" name="completed"<?php echo e($series->completed ? " checked" : ""); ?>><?php echo e(trans('manage/series.completed')); ?>

        </div>
    </div>
    <?php endif; ?>
    <div class="form-group">
        <input type="submit" class="btn btn-block btn-primary" value="<?php echo e($button_text); ?>">
    </div>
    <?php if(isset($status)): ?>
    <div class="form-group">
        <a href="javascript:;" id="delete-btn" class="btn btn-block btn-danger"><?php echo e(trans('manage/series.delete_button')); ?></a>
    </div>
    <?php endif; ?>
</form>