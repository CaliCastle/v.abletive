<?php foreach($comments as $comment): ?>
    <?php echo $__env->make('discussion.comment-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; ?>