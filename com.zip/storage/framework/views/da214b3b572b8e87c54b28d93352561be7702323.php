<?php $__env->startSection('title', "\"" . trans('skills.' . $skill->name) . "\" " . trans('header/navbar.skills')); ?>

<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .background-image {
        background: url("<?php echo e($skill->thumbnail); ?>") no-repeat center center;
        background-size: cover;
    }
    header.main-header {
        position: relative;
    }
</style>
<?php $__env->appendSection(); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="header-content">
        <div class="container">
            <div class="banner">
                <div class="col-lg-3">
                    <div class="skill-thumbnail animated animated-delay1 bounceInDown">
                        <img src="<?php echo e($skill->thumbnail); ?>" alt="<?php echo e(trans('skills.' . $skill->name)); ?>">
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="skill-details">
                        <h1 class="skill-heading animated animated-delay3 fadeInUp"><?php echo e("<" . trans('skills.' . $skill->name) . "> " . trans('header/navbar.skills')); ?></h1>
                        <p class="skill-message animated animated-delay5 fadeInUp">
                            <?php echo $skill->description; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                <div class="col-lg-12">
                    <ul class="skill-status">
                        <li class="animated animated-delay5 fadeInRight">
                            <span><?php echo e($skill->series->count()); ?></span> <?php echo e(trans('series.title')); ?>

                        </li>
                        <li class="animated animated-delay7 fadeInRight">
                            <span><?php echo e($skill->lessonsCount()); ?></span> <?php echo e(trans('lessons.skill_lessons')); ?>

                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-content">
    <div class="container">
        <div class="row">
            <div class="section">
                <div class="series-collection">
                <?php $__empty_1 = true; foreach($skill->series as $series): $__empty_1 = false; ?>
                    <?php echo $__env->make('series.partials.series-tiles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; if ($__empty_1): ?>
                    <h2 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('header/navbar.skills')])); ?></h2>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.partials.level-up', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>