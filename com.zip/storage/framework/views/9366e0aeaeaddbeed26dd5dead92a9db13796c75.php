<?php $__env->startSection('title', trans('manage/users.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="setting flex-container">
            <?php echo $__env->make('manage.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <aside class="box-right">
                <div class="content">
                    <h2 class="heading"><?php echo e(trans('manage/users.title')); ?></h2>
                    <div class="row">
                        <?php if(count($users)): ?>
                            <table class="table table-responsive table-striped">
                                <thead>
                                <tr>
                                    <td><?php echo e(trans('manage/users.name')); ?></td>
                                    <td><?php echo e(trans('manage/users.email')); ?></td>
                                    <td><?php echo e(trans('manage/users.role')); ?></td>
                                    <td></td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($users as $user): ?>
                                    <tr data-id="<?php echo e($user->id); ?>">
                                        <td><?php echo e($user->display_name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->role); ?></td>
                                        <td>
                                            <?php if ( ! ($user->id == auth()->user()->id)): ?>
                                            <a href="javascript:;" id="promote-btn"><?php echo e($user->isTutor() || $user->isManager() ? trans('manage/users.unpromote') : trans('manage/users.promote')); ?></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <h3 class="no-result"><?php echo e(trans('messages.no_result', ["name" => trans('auth.user')])); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts.footer'); ?>
<script>
    $(function () {
        $('a#promote-btn').each(function () {
            $(this).click(function () {
                var $id = $($(this).parents('tr')[0]).attr('data-id');
                swal({
                    title: "<?php echo e(trans('manage/users.promote-title')); ?>",
                    type: "warning",
                    showCancelButton: true,
                    showConfirmButton: true
                }, function () {
                    $.ajax({
                        url: "<?php echo e(url('manage/users/promote/')); ?>/" + $id,
                        data: {_token: "<?php echo e(csrf_token()); ?>"},
                        type: "PUT",
                        success: function (data) {
                            swal({title:data.message, timer: 1000, type: data.status, showConfirmButton: false});
                        }
                    });
                });
            });
        });
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>