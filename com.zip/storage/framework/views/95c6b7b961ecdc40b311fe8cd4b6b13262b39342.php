<nav class="main-nav">
    <ul>
        <li<?php echo e(request()->getRequestUri() == "/settings" ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('settings')); ?>"><?php echo e(trans('setting/sidebar.account')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(request()->getRequestUri() == "/settings/notification" ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('settings/notification')); ?>"><?php echo e(trans('setting/sidebar.notification')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(request()->getRequestUri() == "/settings/subscription" ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('settings/subscription')); ?>"><?php echo e(trans('setting/sidebar.subscription')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
        <li<?php echo e(request()->getRequestUri() == "/settings/level" ? " class=active" : ''); ?>>
            <a href="<?php echo e(url('settings/level')); ?>"><?php echo e(trans('setting/sidebar.level')); ?></a>
            <i class="fa fa-chevron-right"></i>
        </li>
    </ul>
</nav>